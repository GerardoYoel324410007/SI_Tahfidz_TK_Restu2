<?php require_once __DIR__ . '/../../config/view_auth.php'; requireRole('wali_murid'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Riwayat Koreksi - Tahfidz Parent Portal</title>
    <meta name="description" content="Catatan dan umpan balik guru tahfidz untuk perkembangan hafalan anak.">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                "colors": { "on-surface": "#191c1c","background": "#f8faf9","on-primary-fixed": "#00210e","on-primary-container": "#8ad2a0","surface-bright": "#f8faf9","surface": "#f8faf9","surface-variant": "#e1e3e2","secondary-container": "#fe8a29","surface-container-lowest": "#ffffff","on-primary": "#ffffff","primary": "#004323","on-tertiary-container": "#aac1ff","on-error": "#ffffff","on-secondary": "#ffffff","outline-variant": "#bfc9bf","secondary": "#964900","primary-fixed": "#a9f3be","on-tertiary": "#ffffff","on-primary-fixed-variant": "#00522c","error-container": "#ffdad6","tertiary": "#003580","tertiary-fixed": "#d9e2ff","on-secondary-fixed": "#311300","primary-fixed-dim": "#8dd6a3","on-secondary-container": "#642f00","outline": "#707a70","on-surface-variant": "#404941","on-background": "#191c1c","inverse-primary": "#8dd6a3","inverse-surface": "#2e3131","surface-container-highest": "#e1e3e2","surface-container-low": "#f2f4f3","surface-container": "#eceeed","surface-container-high": "#e6e9e8","on-error-container": "#93000a","primary-container": "#0d5c34","tertiary-fixed-dim": "#b0c6ff","on-tertiary-fixed-variant": "#00429c","tertiary-container": "#004aae","surface-tint": "#226b41","surface-dim": "#d8dada","secondary-fixed-dim": "#ffb786","on-tertiary-fixed": "#001945","inverse-on-surface": "#eff1f0","secondary-fixed": "#ffdcc6","on-secondary-fixed-variant": "#723600","error": "#ba1a1a" },
                "borderRadius": {"DEFAULT": "1rem","lg": "2rem","xl": "3rem","full": "9999px"},
                "spacing": {"container-padding-sm": "16px","margin-mobile": "16px","base": "8px","margin-desktop": "48px","container-padding-md": "24px","gutter": "20px"},
                "fontFamily": {"headline-lg-mobile": ["Plus Jakarta Sans"],"headline-lg": ["Plus Jakarta Sans"],"body-md": ["Plus Jakarta Sans"],"label-md": ["Plus Jakarta Sans"],"headline-md": ["Plus Jakarta Sans"],"headline-sm": ["Plus Jakarta Sans"],"body-lg": ["Plus Jakarta Sans"]},
                "fontSize": { "headline-lg-mobile": ["26px",{"lineHeight":"34px","fontWeight":"700"}],"headline-lg": ["32px",{"lineHeight":"40px","letterSpacing":"-0.02em","fontWeight":"700"}],"body-md": ["16px",{"lineHeight":"24px","fontWeight":"400"}],"label-md": ["14px",{"lineHeight":"20px","fontWeight":"600"}],"headline-md": ["24px",{"lineHeight":"32px","letterSpacing":"-0.01em","fontWeight":"700"}],"headline-sm": ["20px",{"lineHeight":"28px","fontWeight":"600"}],"body-lg": ["18px",{"lineHeight":"26px","fontWeight":"500"}] }
            }}
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; min-height: max(884px, 100dvh); background-color: #f8faf9; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        .chat-bubble-left { border-radius: 1.5rem 1.5rem 1.5rem 0.2rem; }
        .chat-bubble-right { border-radius: 1.5rem 1.5rem 0.2rem 1.5rem; }
    </style>
    <script src="../../assets/js/api.js?v=5"></script>
    <script src="../../assets/js/auth-guard.js?v=5"></script>
</head>
<body class="font-body-md text-on-surface">
    <!-- Top App Bar -->
    <header class="bg-primary dark:bg-primary-container text-on-primary rounded-b-lg shadow-[0px_20px_40px_rgba(0,67,35,0.15)] flex justify-between items-center px-margin-mobile py-3 sticky top-0 z-50 w-full">
        <div class="flex items-center gap-3">
            <a href="beranda.php" class="text-on-primary hover:opacity-80">
                <span class="material-symbols-outlined">arrow_back</span>
            </a>
            <div class="w-8 h-8 rounded-full overflow-hidden border-2 border-primary-fixed bg-white flex items-center justify-center ml-1">
                <img alt="Logo Restu Z" class="w-full h-full object-contain p-0.5" src="../../LOGO Restu 2 Excellent.png">
            </div>
            <h1 class="font-headline-sm text-headline-sm-mobile md:text-headline-sm font-bold">Catatan Ustadz</h1>
        </div>
        <div class="flex items-center gap-3">
            <button onclick="authGuard.logout()" class="bg-[#ba1a1a] text-white px-4 py-1.5 rounded-full font-bold text-xs active:scale-95 transition-all flex items-center gap-1.5 shadow-md hover:bg-[#ba1a1a]/90" title="Logout">
                <span class="material-symbols-outlined text-sm">logout</span>
                <span>Keluar</span>
            </button>
        </div>
    </header>

    <main class="px-margin-mobile pt-6 pb-32 max-w-2xl mx-auto">
        <!-- Status & Title -->
        <div class="flex flex-col gap-4 mb-8">
            <div class="flex justify-between items-end">
                <div>
                    <h2 class="font-headline-md text-headline-md text-primary mb-1">Riwayat Koreksi</h2>
                    <p id="koreksi-detail-title" class="font-label-md text-label-md text-on-surface-variant">-</p>
                </div>
                <!-- Status Badge -->
                <div id="status-badge" class="hidden"></div>
            </div>
        </div>

        <!-- Chat History -->
        <div class="space-y-6">
            <div class="text-center py-8 text-on-surface-variant">Memuat detail koreksi...</div>
        </div>
    </main>

    <!-- Reply & Bottom Navigation -->
    <div class="fixed bottom-0 left-0 w-full z-50 bg-surface shadow-[0px_-4px_20px_rgba(0,0,0,0.05)]">
        <!-- Bottom Nav -->
        <nav class="flex justify-around items-center px-2 pb-4 pt-2">
            <a class="flex flex-col items-center justify-center text-on-surface-variant hover:bg-surface-container-high px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200" href="beranda.php">
                <span class="material-symbols-outlined">home</span>
                <span class="font-label-md text-xs mt-1">Home</span>
            </a>
            <a class="flex flex-col items-center justify-center text-on-surface-variant hover:bg-surface-container-high px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200 relative" href="setoran.php">
                <span class="material-symbols-outlined">cloud_upload</span>
                <span class="font-label-md text-xs mt-1">Setor</span>
                <span id="setor-notif-dot" class="absolute top-2 right-6 w-2.5 h-2.5 bg-red-600 rounded-full hidden"></span>
            </a>
            <a class="flex flex-col items-center justify-center bg-secondary-container text-on-secondary-container rounded-2xl px-5 py-2 active:scale-90 transition-all duration-200" href="histori.php">
                <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">history</span>
                <span class="font-label-md text-xs mt-1">Histori</span>
            </a>
            <a class="flex flex-col items-center justify-center text-on-surface-variant hover:bg-surface-container-high px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200" href="raport.php">
                <span class="material-symbols-outlined">insights</span>
                <span class="font-label-md text-xs mt-1">Progress</span>
            </a>
            <button onclick="authGuard.logout()" class="flex flex-col items-center justify-center text-[#ba1a1a] hover:bg-red-50 px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200">
                <span class="material-symbols-outlined">logout</span>
                <span class="font-label-md text-xs mt-1">Keluar</span>
            </button>
        </nav>
    </div>

    <script>
    let setoranId = null;

    document.addEventListener('DOMContentLoaded', async () => {
        const params = new URLSearchParams(window.location.search);
        setoranId = params.get('setoran_id');

        if (!setoranId) {
            document.querySelector('main').innerHTML = '<div class="text-center py-16"><p class="text-on-surface-variant">Setoran tidak ditemukan.</p></div>';
            return;
        }

        try {
            const res = await api.get(`/api/wali/detail-koreksi.php?setoran_id=${setoranId}`);
            const d = res.data;
            const s = d.setoran;

            const babText = s.bab ? ` (${s.bab})` : '';
            document.getElementById('koreksi-detail-title').textContent = `QS. ${s.nama_surat}${babText}: Ayat ${s.ayat_dari}-${s.ayat_sampai}`;

            // Update status badge
            const badge = document.getElementById('status-badge');
            badge.classList.remove('hidden');
            if (s.status === 'diterima') {
                badge.className = 'bg-primary-fixed text-on-primary-fixed px-6 py-2 rounded-full font-bold shadow-sm border-2 border-primary/10 flex items-center gap-2';
                badge.innerHTML = '<span class="material-symbols-outlined text-[20px]" style="font-variation-settings: \'FILL\' 1;">check_circle</span><span class="text-label-md tracking-wider">DITERIMA</span>';
            } else if (s.status === 'perbaiki') {
                badge.className = 'bg-error-container text-on-error-container px-6 py-2 rounded-full font-bold shadow-sm border-2 border-error/10 flex items-center gap-2';
                badge.innerHTML = '<span class="material-symbols-outlined text-[20px]" style="font-variation-settings: \'FILL\' 1;">error</span><span class="text-label-md tracking-wider">PERBAIKI</span>';
            }

            // Build chat
            const chatArea = document.querySelector('.space-y-6');
            let chatHTML = '';

            // Student audio
            if (s.file_audio) {
                chatHTML += `
                <div class="flex flex-col items-end gap-2">
                    <div class="chat-bubble-right bg-primary-container text-on-primary shadow-lg p-4 w-full sm:w-3/4">
                        <div class="flex items-center gap-4">
                            <button onclick="playStudentAudio(api.toAbsoluteUrl('/${s.file_audio}'))" class="w-12 h-12 rounded-full bg-on-primary-container text-primary flex items-center justify-center hover:bg-primary-fixed transition-colors">
                                <span class="material-symbols-outlined text-[32px]" style="font-variation-settings: 'FILL' 1;">play_arrow</span>
                            </button>
                            <div class="flex-1">
                                <p class="font-label-md text-sm opacity-80">Rekaman Hafalan</p>
                            </div>
                        </div>
                    </div>
                    <span class="text-[12px] text-on-surface-variant font-medium mr-2">${api.formatTime(s.waktu_kirim)}</span>
                </div>`;
            }

            // Teacher feedback
            if (s.catatan_guru || s.nilai_label || s.nilai_poin) {
                let gradeCardHTML = '';
                const mainLabel = s.nilai_label || (s.nilai_poin === 4 ? 'BSB' : s.nilai_poin === 3 ? 'BSH' : s.nilai_poin === 2 ? 'MB' : s.nilai_poin === 1 ? 'BB' : null);
                if (mainLabel) {
                    let colorBadge = 'bg-emerald-100 text-emerald-800 border-emerald-300';
                    let stars = '⭐⭐⭐⭐';
                    let desc = 'Berkembang Sangat Baik';
                    if (mainLabel === 'BSH') { colorBadge = 'bg-blue-100 text-blue-800 border-blue-300'; stars = '⭐⭐⭐'; desc = 'Berkembang Sesuai Harapan'; }
                    else if (mainLabel === 'MB') { colorBadge = 'bg-amber-100 text-amber-800 border-amber-300'; stars = '⭐⭐'; desc = 'Mulai Berkembang'; }
                    else if (mainLabel === 'BB') { colorBadge = 'bg-red-100 text-red-800 border-red-300'; stars = '⭐'; desc = 'Belum Berkembang'; }

                    gradeCardHTML = `
                    <div class="mb-3 p-3.5 rounded-xl border ${colorBadge} flex items-center justify-between">
                        <div>
                            <span class="text-xs font-bold uppercase block tracking-wider opacity-80">Nilai Capaian Tahfidz</span>
                            <span class="text-lg font-black block">${mainLabel} — ${desc}</span>
                        </div>
                        <span class="text-xl">${stars}</span>
                    </div>`;
                }

                chatHTML += `
                <div class="flex flex-col items-start gap-2">
                    <div class="flex items-center gap-2 mb-1">
                        <div class="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-on-primary">
                            <span class="material-symbols-outlined text-[14px]">school</span>
                        </div>
                        <span class="font-label-md text-primary font-bold">Catatan Ustadz</span>
                    </div>
                    <div class="chat-bubble-left bg-surface-container-highest text-on-surface shadow-md p-4 w-full sm:w-4/5 border-l-4 border-primary space-y-2">
                        ${gradeCardHTML}
                        ${s.catatan_guru ? `<p class="font-body-md text-body-md leading-relaxed">${s.catatan_guru}</p>` : ''}
                    </div>
                    <span class="text-[12px] text-on-surface-variant font-medium ml-2">${api.formatTime(s.waktu_koreksi)}</span>
                </div>`;
            } else {
                chatHTML += '<p class="text-center text-on-surface-variant">Guru belum memberikan catatan.</p>';
            }

            // Detail koreksi kriteria
            if (d.detail_koreksi && d.detail_koreksi.length > 0) {
                chatHTML += '<div class="bg-surface-container-lowest rounded-lg p-4 border border-outline-variant/30 space-y-3">';
                chatHTML += '<p class="font-label-md text-label-md text-primary font-bold">Rincian Penilaian Kriteria:</p>';
                d.detail_koreksi.forEach(item => {
                    const strVal = String(item.nilai).trim().toUpperCase();
                    let category = '';
                    if (strVal === '4' || strVal === 'BSB') category = 'BSB ⭐⭐⭐⭐';
                    else if (strVal === '3' || strVal === 'BSH') category = 'BSH ⭐⭐⭐';
                    else if (strVal === '2' || strVal === 'MB') category = 'MB ⭐⭐';
                    else if (strVal === '1' || strVal === 'BB') category = 'BB ⭐';
                    else {
                        const num = parseFloat(strVal);
                        if (!isNaN(num)) {
                            if (num >= 90) category = `${num}/100 (BSB ⭐⭐⭐⭐)`;
                            else if (num >= 75) category = `${num}/100 (BSH ⭐⭐⭐)`;
                            else if (num >= 60) category = `${num}/100 (MB ⭐⭐)`;
                            else category = `${num}/100 (BB ⭐)`;
                        } else {
                            category = item.nilai;
                        }
                    }
                    chatHTML += `<div class="flex justify-between items-center py-1 border-b border-outline-variant/20 last:border-none"><span class="text-on-surface-variant font-semibold text-sm">${item.kriteria}</span><span class="font-bold text-primary text-sm">${category}</span></div>`;
                });
                chatHTML += '</div>';
            }

            chatArea.innerHTML = chatHTML;
            
            // Check pending task to display notification dot
            checkPendingTask();
        } catch (err) {
            console.error('Gagal memuat detail koreksi:', err);
        }
    });

    async function checkPendingTask() {
        try {
            const res = await api.get('/api/wali/tugas-hari-ini.php');
            const d = res.data;
            if (d.tugas && !d.setoran && !d.is_locked) {
                const dot = document.getElementById('setor-notif-dot');
                if (dot) dot.classList.remove('hidden');
            }
        } catch (err) {
            console.error('Gagal mengecek tugas tertunda:', err);
        }
    }

    function playStudentAudio(src) {
        if (window.currentPlayingAudio) {
            window.currentPlayingAudio.pause();
        }
        const audio = new Audio(src);
        window.currentPlayingAudio = audio;
        audio.play().catch(e => {
            console.error("Gagal memutar audio:", e);
            api.toast("Gagal memutar rekaman: " + e.message, "error");
        });
    }

    </script>
</body>
</html>
