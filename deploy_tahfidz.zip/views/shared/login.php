<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Login - Sistem Informasi Tahfidz</title>
    <meta name="description" content="Portal login sistem informasi Tahfidz KB-BA-TPA Restu 2.">
    <link rel="icon" type="image/png" href="../../LOGO Restu 2 Excellent.png">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="../../assets/css/fontawesome/all.min.css" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                "colors": { "primary": "#004323", "tertiary": "#003580", "secondary": "#964900", "secondary-container": "#fe8a29", "surface": "#f8faf9", "surface-container": "#eceeed", "surface-container-low": "#f2f4f3", "surface-container-lowest": "#ffffff", "surface-container-high": "#e6e9e8", "surface-container-highest": "#e1e3e2", "on-surface": "#191c1c", "on-surface-variant": "#404941", "outline": "#707a70", "outline-variant": "#bfc9bf", "error": "#ba1a1a", "error-container": "#ffdad6", "on-error": "#ffffff", "on-error-container": "#93000a", "primary-fixed": "#a9f3be", "on-primary": "#ffffff", "on-primary-fixed-variant": "#00522c" },
                "borderRadius": {"DEFAULT": "1rem","lg": "2rem","xl": "3rem","full": "9999px"},
                "fontFamily": {"body": ["Poppins"], "heading": ["Poppins"]}
            }}
        }
    </script>
    <style>
        body { 
            font-family: 'Poppins', sans-serif; 
            background-color: #f8faf9; 
            min-height: 100vh; 
            min-height: 100dvh; /* Dynamic viewport height untuk mobile */
        }
        .bg-mesh { background-image: radial-gradient(at 10% 10%, rgba(255,255,255,0.1) 0px, transparent 40%), radial-gradient(at 90% 90%, rgba(254,138,41,0.15) 0px, transparent 40%); }
        
        /* Pastikan bisa di-scroll di mobile */
        @media (max-height: 700px) {
            .login-container {
                min-height: auto !important;
            }
        }
    </style>
</head>
<body class="bg-primary text-on-surface bg-mesh relative p-4 overflow-x-hidden flex items-center justify-center">
    <div class="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] bg-white opacity-5 rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute bottom-[-10%] right-[-10%] w-[30vw] h-[30vw] bg-secondary-container opacity-20 rounded-full blur-3xl pointer-events-none"></div>

    <div class="login-container w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 bg-white rounded-3xl overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)] z-10 relative my-auto">
        <!-- Left Side: Login Form -->
        <div class="p-6 md:p-16 flex flex-col justify-center relative">
            <div class="max-w-sm w-full mx-auto">
                <div class="w-20 h-20 bg-white rounded-2xl flex items-center justify-center p-1 mb-8 border border-primary/20 shadow-sm mx-auto">
                    <img alt="Logo Restu 2 Excellent" class="w-full h-full object-contain" src="../../LOGO Restu 2 Excellent.png">
                </div>

                <h2 class="text-2xl md:text-3xl font-bold text-on-surface mb-2 tracking-tight text-center">Masuk Aplikasi</h2>
                <p class="text-on-surface-variant mb-6 md:mb-10 text-sm md:text-base text-center">Sistem Informasi Tahfidz KB-BA-TPA Restu 2</p>

                <form id="loginForm" class="space-y-6" onsubmit="handleLogin(event)">
                    <div>
                        <label class="block text-sm font-semibold text-on-surface mb-2 pl-1">Nomor Identitas</label>
                        <div class="relative">
                            <i class="fa-solid fa-id-card absolute left-4 top-1/2 -translate-y-1/2 text-outline-variant"></i>
                            <input type="text" id="nomor_identitas"
                                class="w-full bg-surface border-2 border-outline-variant rounded-full pl-12 pr-4 py-3 md:py-4 text-on-surface focus:border-primary focus:ring-0 transition-colors"
                                placeholder="NUPTK/NIK/NIS (maks. 50 karakter)"
                                maxlength="50"
                                required>
                        </div>
                        <p class="text-xs text-on-surface-variant mt-1 pl-2">Masukkan NUPTK (Guru), NIK (Guru), atau NIS (Wali Murid)</p>
                    </div>

                    <div>
                        <label class="block text-sm font-semibold text-on-surface mb-2 pl-1">Password</label>
                        <div class="relative">
                            <i class="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-outline-variant"></i>
                            <input type="password" id="password"
                                class="w-full bg-surface border-2 border-outline-variant rounded-full pl-12 pr-12 py-3 md:py-4 text-on-surface focus:border-primary focus:ring-0 transition-colors"
                                placeholder="Masukkan password"
                                minlength="6"
                                maxlength="50"
                                required>
                            <button type="button" class="absolute right-4 top-1/2 -translate-y-1/2 text-outline-variant hover:text-primary transition-colors"
                                onclick="togglePassword()">
                                <i class="fa-solid fa-eye" id="eye-icon"></i>
                            </button>
                        </div>
                    </div>

                    <div id="error-msg" class="hidden bg-error-container text-on-error-container px-4 py-3 rounded-xl text-sm">
                        <i class="fa-solid fa-circle-exclamation mr-2"></i>
                        <span id="error-text"></span>
                    </div>

                    <div class="pt-2 md:pt-4">
                        <button type="submit" id="btn-login"
                            class="w-full bg-primary text-white py-3 md:py-4 rounded-full text-base md:text-lg font-semibold shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:scale-95 transition-all flex items-center justify-center gap-2 group">
                            Masuk Aplikasi
                            <i class="fa-solid fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                        </button>
                    </div>
                </form>
            </div>

            <div class="mt-8 text-center lg:absolute lg:bottom-8 lg:left-0 lg:w-full">
                <p class="text-[12px] text-outline">Sistem Informasi Tahfidz v1.0.0</p>
            </div>
        </div>

        <!-- Right Side: Info Panel (Hidden on mobile) -->
        <div class="hidden lg:flex bg-surface-container flex-col justify-between p-8 xl:p-12 relative overflow-hidden">
            <div class="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none">
                <svg width="100%" height="100%">
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" stroke-width="1"/>
                    </pattern>
                    <rect width="100%" height="100%" fill="url(#grid)" class="text-primary"/>
                </svg>
            </div>

            <div class="relative z-10 space-y-4 max-w-md">
                <span class="px-4 py-2 bg-primary-fixed text-on-primary-fixed-variant rounded-full text-sm font-bold inline-flex items-center gap-2 border border-primary/20">
                    <span class="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                    Sistem Berjalan Normal
                </span>
                <h3 class="text-3xl font-bold text-primary leading-tight mt-6">Pantau & Kelola Hafalan Al-Quran</h3>
                <p class="text-on-surface-variant">Akses penuh untuk Admin, Guru Wali Kelas, dan Wali Murid dalam satu portal terpadu.</p>
            </div>

            <div class="relative z-10 grid grid-cols-3 gap-4 mt-auto">
                <div class="bg-white/60 backdrop-blur-sm p-4 rounded-2xl border border-white text-center">
                    <i class="fa-solid fa-shield-halved text-primary text-2xl mb-2"></i>
                    <p class="text-xs font-semibold text-on-surface">Admin</p>
                    <p class="text-[10px] text-on-surface-variant">Kelola Data</p>
                </div>
                <div class="bg-white/60 backdrop-blur-sm p-4 rounded-2xl border border-white text-center">
                    <i class="fa-solid fa-chalkboard-teacher text-tertiary text-2xl mb-2"></i>
                    <p class="text-xs font-semibold text-on-surface">Guru</p>
                    <p class="text-[10px] text-on-surface-variant">Koreksi Setoran</p>
                </div>
                <div class="bg-white/60 backdrop-blur-sm p-4 rounded-2xl border border-white text-center">
                    <i class="fa-solid fa-users text-secondary text-2xl mb-2"></i>
                    <p class="text-xs font-semibold text-on-surface">Wali Murid</p>
                    <p class="text-[10px] text-on-surface-variant">Pantau Anak</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ═══════════════════════════════════════════════════════════ -->
    <!-- MODAL: Ganti Password Pertama                              -->
    <!-- Muncul otomatis jika user masih pakai password default     -->
    <!-- ═══════════════════════════════════════════════════════════ -->
    <div id="modal-ganti-password" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4"
         role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <!-- Backdrop blur -->
        <div class="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>

        <!-- Card -->
        <div class="relative bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-[fadeInUp_0.3s_ease-out]">
            <!-- Header hijau -->
            <div class="bg-primary px-8 pt-8 pb-6">
                <div class="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mb-4">
                    <i class="fa-solid fa-key text-white text-2xl"></i>
                </div>
                <h2 id="modal-title" class="text-xl font-bold text-white">Buat Password Baru</h2>
                <p class="text-white/80 text-sm mt-1">Anda menggunakan password default. Wajib dibuat password baru sebelum melanjutkan.</p>
            </div>

            <!-- Body -->
            <div class="px-8 py-6 space-y-5">
                <!-- Info banner -->
                <div class="bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex gap-3 items-start">
                    <i class="fa-solid fa-triangle-exclamation text-amber-500 mt-0.5 flex-shrink-0"></i>
                    <p class="text-amber-800 text-xs leading-relaxed">
                        Password minimal <strong>8 karakter</strong>. Perubahan ini akan <strong>langsung berlaku</strong> dan tercatat oleh admin.
                    </p>
                </div>

                <form id="formGantiPassword" class="space-y-4" onsubmit="submitGantiPassword(event)">
                    <!-- Password Baru -->
                    <div>
                        <label class="block text-sm font-semibold text-on-surface mb-1.5 pl-1">Password Baru</label>
                        <div class="relative">
                            <i class="fa-solid fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-outline-variant"></i>
                            <input type="password" id="modal-password-baru"
                                class="w-full bg-surface border-2 border-outline-variant rounded-full pl-12 pr-12 py-3 text-on-surface focus:border-primary focus:ring-0 transition-colors text-sm"
                                placeholder="Min. 8 karakter"
                                minlength="8" maxlength="50" required autocomplete="new-password">
                            <button type="button" onclick="toggleModalPassword('modal-password-baru', 'eye1')"
                                class="absolute right-4 top-1/2 -translate-y-1/2 text-outline-variant hover:text-primary transition-colors">
                                <i class="fa-solid fa-eye" id="eye1"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Konfirmasi Password -->
                    <div>
                        <label class="block text-sm font-semibold text-on-surface mb-1.5 pl-1">Konfirmasi Password</label>
                        <div class="relative">
                            <i class="fa-solid fa-lock-open absolute left-4 top-1/2 -translate-y-1/2 text-outline-variant"></i>
                            <input type="password" id="modal-konfirmasi"
                                class="w-full bg-surface border-2 border-outline-variant rounded-full pl-12 pr-12 py-3 text-on-surface focus:border-primary focus:ring-0 transition-colors text-sm"
                                placeholder="Ulangi password baru"
                                minlength="8" maxlength="50" required autocomplete="new-password">
                            <button type="button" onclick="toggleModalPassword('modal-konfirmasi', 'eye2')"
                                class="absolute right-4 top-1/2 -translate-y-1/2 text-outline-variant hover:text-primary transition-colors">
                                <i class="fa-solid fa-eye" id="eye2"></i>
                            </button>
                        </div>
                    </div>

                    <!-- Error modal -->
                    <div id="modal-error" class="hidden bg-error-container text-on-error-container px-4 py-3 rounded-xl text-sm">
                        <i class="fa-solid fa-circle-exclamation mr-2"></i>
                        <span id="modal-error-text"></span>
                    </div>

                    <!-- Strength indicator -->
                    <div id="strength-bar-wrap" class="hidden">
                        <div class="flex gap-1 mb-1">
                            <div class="h-1.5 flex-1 rounded-full bg-outline-variant" id="s1"></div>
                            <div class="h-1.5 flex-1 rounded-full bg-outline-variant" id="s2"></div>
                            <div class="h-1.5 flex-1 rounded-full bg-outline-variant" id="s3"></div>
                            <div class="h-1.5 flex-1 rounded-full bg-outline-variant" id="s4"></div>
                        </div>
                        <p class="text-xs text-on-surface-variant" id="strength-label">Lemah</p>
                    </div>

                    <button type="submit" id="btn-ganti-password"
                        class="w-full bg-primary text-white py-3 rounded-full text-sm font-semibold shadow-md hover:shadow-lg hover:-translate-y-0.5 active:scale-95 transition-all flex items-center justify-center gap-2">
                        <i class="fa-solid fa-shield-check"></i>
                        Simpan Password Baru
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // ── Toggle password visibility (form login) ──────────────────────
        function togglePassword() {
            const input = document.getElementById('password');
            const icon = document.getElementById('eye-icon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        // ── Toggle password visibility (modal) ──────────────────────────
        function toggleModalPassword(inputId, iconId) {
            const input = document.getElementById(inputId);
            const icon  = document.getElementById(iconId);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        // ── Password strength meter ──────────────────────────────────────
        const strengthColors = ['bg-error', 'bg-orange-400', 'bg-yellow-400', 'bg-green-500'];
        document.addEventListener('DOMContentLoaded', () => {
            document.getElementById('modal-password-baru')?.addEventListener('input', function () {
                const val  = this.value;
                const wrap = document.getElementById('strength-bar-wrap');
                if (!val) { wrap.classList.add('hidden'); return; }
                wrap.classList.remove('hidden');

                let score = 0;
                if (val.length >= 8)  score++;
                if (/[A-Z]/.test(val)) score++;
                if (/[0-9]/.test(val)) score++;
                if (/[^A-Za-z0-9]/.test(val)) score++;

                const labels = ['Sangat Lemah', 'Lemah', 'Sedang', 'Kuat'];
                document.getElementById('strength-label').textContent = labels[score - 1] || 'Sangat Lemah';

                ['s1','s2','s3','s4'].forEach((id, i) => {
                    const el = document.getElementById(id);
                    el.className = 'h-1.5 flex-1 rounded-full ' +
                        (i < score ? strengthColors[score - 1] : 'bg-outline-variant');
                });
            });
        });

        // ── Redirect menyimpan URL tujuan ──────────────────────────────
        let _pendingRedirect = null;

        function showModalGantiPassword(redirectUrl) {
            _pendingRedirect = redirectUrl;
            document.getElementById('modal-ganti-password').classList.remove('hidden');
            setTimeout(() => document.getElementById('modal-password-baru')?.focus(), 100);
        }

        // ── Submit ganti password pertama ───────────────────────────────
        async function submitGantiPassword(e) {
            e.preventDefault();
            const errEl  = document.getElementById('modal-error');
            const errTxt = document.getElementById('modal-error-text');
            errEl.classList.add('hidden');

            const passwordBaru = document.getElementById('modal-password-baru').value;
            const konfirmasi   = document.getElementById('modal-konfirmasi').value;

            if (passwordBaru.length < 8) {
                errTxt.textContent = 'Password minimal 8 karakter.';
                errEl.classList.remove('hidden');
                return;
            }
            if (passwordBaru !== konfirmasi) {
                errTxt.textContent = 'Konfirmasi password tidak cocok.';
                errEl.classList.remove('hidden');
                return;
            }

            const btn = document.getElementById('btn-ganti-password');
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Menyimpan...';

            try {
                const res  = await fetch('../../api/auth/ganti-password-pertama.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ password_baru: passwordBaru, konfirmasi: konfirmasi }),
                });
                const data = await res.json();

                if (data.status === 'success') {
                    btn.innerHTML = '<i class="fa-solid fa-check mr-2"></i> Tersimpan! Mengalihkan...';
                    btn.classList.replace('bg-primary', 'bg-green-600');
                    setTimeout(() => {
                        window.location.href = _pendingRedirect || '../../views/shared/login.php';
                    }, 900);
                } else {
                    errTxt.textContent = data.message || 'Terjadi kesalahan. Coba lagi.';
                    errEl.classList.remove('hidden');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fa-solid fa-shield-check"></i> Simpan Password Baru';
                }
            } catch (err) {
                errTxt.textContent = 'Gagal terhubung ke server. Coba lagi.';
                errEl.classList.remove('hidden');
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-shield-check"></i> Simpan Password Baru';
            }
        }

        // ── Error helpers (form login) ───────────────────────────────────
        function showError(msg) {
            const el = document.getElementById('error-msg');
            document.getElementById('error-text').textContent = msg;
            el.classList.remove('hidden');
        }

        function hideError() {
            document.getElementById('error-msg').classList.add('hidden');
        }

        // ── Handle Login ─────────────────────────────────────────────────
        async function handleLogin(e) {
            e.preventDefault();
            hideError();

            const nomor    = document.getElementById('nomor_identitas').value.trim();
            const password = document.getElementById('password').value;

            if (nomor.length < 1 || nomor.length > 50) {
                showError('Nomor identitas tidak valid (maksimal 50 karakter).');
                return;
            }
            if (password.length < 6) {
                showError('Password minimal 6 karakter.');
                return;
            }

            const btn = document.getElementById('btn-login');
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Memproses...';

            try {
                const response = await fetch('../../api/auth/login.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ nomor_identitas: nomor, password: password }),
                });

                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (parseErr) {
                    showError('Terjadi kesalahan server. Coba lagi.');
                    btn.disabled = false;
                    btn.innerHTML = 'Masuk Aplikasi <i class="fa-solid fa-arrow-right ml-2"></i>';
                    return;
                }

                if (data.status === 'success') {
                    const roleRedirects = {
                        'admin'     : '../../views/admin/dashboard.php',
                        'guru'      : '../../views/guru/beranda.php',
                        'karyawan'  : '../../views/guru/beranda.php',
                        'wali_murid': '../../views/wali_murid/beranda.php',
                    };
                    const redirectUrl = roleRedirects[data.role] || '../../views/shared/login.php';

                    // Langsung redirect (fitur ganti password pertama belum aktif)
                    window.location.href = redirectUrl;
                } else {
                    showError(data.message || 'Login gagal. Periksa nomor identitas dan password.');
                    btn.disabled = false;
                    btn.innerHTML = 'Masuk Aplikasi <i class="fa-solid fa-arrow-right ml-2"></i>';
                }
            } catch (err) {
                showError('Terjadi kesalahan koneksi. Silakan coba lagi.');
                btn.disabled = false;
                btn.innerHTML = 'Masuk Aplikasi <i class="fa-solid fa-arrow-right ml-2"></i>';
            }
        }
    </script>
</body>
</html>
