<?php
/**
 * Auth Check untuk halaman View (views/*.php)
 * Wajib di-include di baris PERTAMA setiap view, sebelum ada output HTML.
 *
 * Usage:
 *   <?php require_once __DIR__ . '/../../config/view_auth.php'; requireRole('admin'); ?>
 *   <?php require_once __DIR__ . '/../../config/view_auth.php'; requireAnyRole(['guru', 'karyawan']); ?>
 */

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/auth.php';

/**
 * Header agar halaman terproteksi tidak disimpan di cache browser
 * (mencegah halaman tampil lagi lewat tombol Back setelah logout).
 */
if (!function_exists('sendNoCacheHeaders')) {
    function sendNoCacheHeaders() {
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: 0');
        }
    }
}

if (!function_exists('redirectToLogin')) {
    function redirectToLogin() {
        header('Location: ' . getBasePath() . '/views/shared/login.php');
        exit;
    }
}

/**
 * Proteksi halaman: redirect jika belum login
 */
if (!function_exists('requireLogin')) {
    function requireLogin() {
        sendNoCacheHeaders();
        Auth::init();
        if (!Auth::isLoggedIn()) {
            redirectToLogin();
        }
    }
}

/**
 * Proteksi halaman: hanya untuk satu role tertentu
 */
if (!function_exists('requireRole')) {
    function requireRole(string $role) {
        requireAnyRole([$role]);
    }
}

/**
 * Proteksi halaman: hanya untuk salah satu dari beberapa role
 */
if (!function_exists('requireAnyRole')) {
    function requireAnyRole(array $roles) {
        sendNoCacheHeaders();
        Auth::init();
        if (!Auth::isLoggedIn()) {
            redirectToLogin();
        }
        if (!in_array($_SESSION['role'], $roles, true)) {
            Auth::redirectByRole();
            exit;
        }
    }
}

/**
 * Mendapatkan data user yang sedang login
 */
if (!function_exists('getCurrentUser')) {
    function getCurrentUser() {
        return Auth::getCurrentUser();
    }
}

/**
 * Generate CSRF token untuk form
 */
if (!function_exists('csrfToken')) {
    function csrfToken() {
        return Auth::generateCSRFToken();
    }
}

/**
 * Generate CSRF hidden input field
 */
if (!function_exists('csrfField')) {
    function csrfField() {
        $token = csrfToken();
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
    }
}
