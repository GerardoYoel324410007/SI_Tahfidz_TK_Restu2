<?php
/**
 * Entry Point Utama - Sistem Informasi Tahfidz
 * Redirect berdasarkan role pengguna menggunakan Auth::redirectByRole()
 */

require_once __DIR__ . '/config/auth.php';

Auth::redirectByRole();
