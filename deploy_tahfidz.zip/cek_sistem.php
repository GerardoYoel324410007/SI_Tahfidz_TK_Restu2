<?php
/**
 * Halaman Cek Kesiapan Sistem
 * Buka di browser setelah menjalankan setup.php:
 * http://localhost/deploy_tahfidz/cek_sistem.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

function parsePhpSize(string $size): int {
    $size = trim($size);
    if ($size === '') return 0;
    $unit = strtolower(substr($size, -1));
    $val  = (float) $size;
    return match ($unit) {
        'g' => (int) ($val * 1024 * 1024 * 1024),
        'm' => (int) ($val * 1024 * 1024),
        'k' => (int) ($val * 1024),
        default => (int) $val,
    };
}

$checks = [];
$addCheck = function (string $label, bool $ok, string $detail, bool $isWarning = false) use (&$checks) {
    $status = $ok ? 'ok' : ($isWarning ? 'warn' : 'fail');
    $checks[] = compact('label', 'status', 'detail');
};

// 1. Versi PHP
$phpOk = version_compare(PHP_VERSION, '8.0.0', '>=');
$addCheck('Versi PHP (minimal 8.0)', $phpOk, 'Terpasang: PHP ' . PHP_VERSION);

// 2. Ekstensi PHP wajib
$requiredExts = [
    'pdo_mysql' => 'Koneksi database MySQL',
    'zip'       => 'Import & Export Excel (.xlsx)',
    'gd'        => 'Pengolahan file Excel (PhpSpreadsheet)',
    'mbstring'  => 'Pemrosesan teks UTF-8 & Excel',
];
foreach ($requiredExts as $ext => $desc) {
    $loaded = extension_loaded($ext);
    $addCheck("Ekstensi PHP: {$ext}", $loaded, $loaded ? "Aktif ({$desc})" : "Tidak aktif! Aktifkan extension={$ext} di php.ini ({$desc})");
}

// 3. Library Excel (vendor/autoload.php)
$vendorPath = __DIR__ . '/vendor/autoload.php';
$vendorOk   = file_exists($vendorPath);
$addCheck('Library Excel (vendor/autoload.php)', $vendorOk, $vendorOk ? 'Tersedia' : 'Folder vendor/ tidak ditemukan. Import/Export Excel tidak akan berjalan.');

// 4. Folder uploads writable
$uploadDirs = [
    'uploads',
    'uploads/audio',
    'uploads/audio/panduan',
    'uploads/audio/setoran',
];
foreach ($uploadDirs as $dir) {
    $full = __DIR__ . '/' . $dir;
    if (!is_dir($full)) {
        @mkdir($full, 0775, true);
    }
    $writable = is_dir($full) && is_writable($full);
    $addCheck("Folder {$dir}/", $writable, $writable ? 'Ada & bisa ditulisi' : 'Tidak ada atau tidak bisa ditulisi (cek permission)');
}

// 5. Batas upload PHP
$uploadMax = ini_get('upload_max_filesize') ?: '2M';
$postMax   = ini_get('post_max_size') ?: '8M';
$minBytes  = 20 * 1024 * 1024; // 20 MB
$uploadOk  = parsePhpSize($uploadMax) >= $minBytes && parsePhpSize($postMax) >= $minBytes;
$addCheck(
    'Batas Ukuran Upload PHP',
    $uploadOk,
    "upload_max_filesize = {$uploadMax}, post_max_size = {$postMax}" . ($uploadOk ? ' (Cukup)' : ' (Disarankan minimal 20M di php.ini agar audio/Excel besar tidak gagal)'),
    true
);

// 6. Konteks aman untuk mikrofon (localhost atau HTTPS)
$host     = strtolower($_SERVER['HTTP_HOST'] ?? '');
$hostOnly = explode(':', $host)[0];
$isHttps  = !empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off';
$micOk    = $isHttps || in_array($hostOnly, ['localhost', '127.0.0.1', '::1'], true);
$addCheck(
    'Akses Mikrofon Browser (Rekam Audio)',
    $micOk,
    $micOk
        ? "Diakses melalui {$host} (Mikrofon diizinkan browser)"
        : "Diakses melalui {$host} tanpa HTTPS! Browser akan menolak fitur rekam audio. Buka lewat http://localhost/...",
    true
);

// 7. Koneksi Database & Struktur Tabel
// Baca konfigurasi dari config/database.php agar mengikuti perubahan user
$dbConfigFile = __DIR__ . '/config/database.php';
$dbHost = 'localhost';
$dbName = 'tahfidz_restu2';
$dbUser = 'root';
$dbPass = '';
if (file_exists($dbConfigFile)) {
    $cfgSrc = file_get_contents($dbConfigFile);
    if (preg_match('/\$host\s*=\s*[\'"]([^\'"]*)[\'"]/', $cfgSrc, $m))     $dbHost = $m[1];
    if (preg_match('/\$dbname\s*=\s*[\'"]([^\'"]*)[\'"]/', $cfgSrc, $m))   $dbName = $m[1];
    if (preg_match('/\$username\s*=\s*[\'"]([^\'"]*)[\'"]/', $cfgSrc, $m)) $dbUser = $m[1];
    if (preg_match('/\$password\s*=\s*[\'"]([^\'"]*)[\'"]/', $cfgSrc, $m)) $dbPass = $m[1];
}

$pdo = null;
try {
    $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $addCheck("Koneksi Database ({$dbName})", true, "Terhubung ke {$dbHost} sebagai {$dbUser}");
} catch (Throwable $e) {
    $addCheck("Koneksi Database ({$dbName})", false, "Gagal terhubung: " . $e->getMessage() . " — Pastikan MySQL berjalan dan sudah menjalankan setup.php");
}

if ($pdo) {
    $existingTables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $requiredTables = [
        'users', 'guru', 'kelas', 'siswa', 'tugas_hafalan', 'setoran',
        'perpanjangan_waktu', 'pengumuman', 'notifikasi', 'koreksi_detail',
        'login_log', 'permintaan_password', 'presensi_tahfidz', 'surat_al_quran'
    ];
    $missingTables = array_values(array_diff($requiredTables, $existingTables));
    $addCheck(
        'Kelengkapan Tabel Database (14 tabel)',
        empty($missingTables),
        empty($missingTables)
            ? 'Semua 14 tabel tersedia'
            : 'Tabel belum ada: ' . implode(', ', $missingTables) . ' — Jalankan ulang setup.php'
    );

    // Cek kolom penting
    $requiredCols = [
        'users'         => 'must_change_password',
        'kelas'         => 'jenis_kelas',
        'guru'          => 'nik',
        'setoran'       => 'nilai_poin',
        'tugas_hafalan' => 'bab',
    ];
    $missingCols = [];
    foreach ($requiredCols as $tbl => $col) {
        if (in_array($tbl, $existingTables, true)) {
            $cols = $pdo->query("SHOW COLUMNS FROM `{$tbl}`")->fetchAll(PDO::FETCH_COLUMN);
            if (!in_array($col, $cols, true)) {
                $missingCols[] = "{$tbl}.{$col}";
            }
        }
    }
    $addCheck(
        'Kolom Skema Terbaru',
        empty($missingCols),
        empty($missingCols) ? 'Semua kolom terbaru tersedia' : 'Kolom belum ada: ' . implode(', ', $missingCols)
    );

    // Cek akun admin 000001
    if (in_array('users', $existingTables, true)) {
        $admin = $pdo->query("SELECT id, is_active FROM users WHERE nomor_identitas = '000001' LIMIT 1")->fetch();
        $adminOk = $admin && (int) $admin['is_active'] === 1;
        $addCheck(
            'Akun Admin Default (000001)',
            $adminOk,
            $adminOk ? 'Tersedia dan aktif (password default: admin123)' : 'Akun 000001 tidak ditemukan atau nonaktif'
        );
    }

    // Cek data master surat
    if (in_array('surat_al_quran', $existingTables, true)) {
        $suratCount = (int) $pdo->query("SELECT COUNT(*) FROM surat_al_quran")->fetchColumn();
        $addCheck(
            'Data Master Surat Al-Quran',
            $suratCount > 0,
            $suratCount > 0 ? "{$suratCount} surat tersedia" : 'Tabel surat_al_quran masih kosong'
        );
    }
}

$failCount = count(array_filter($checks, fn($c) => $c['status'] === 'fail'));
$warnCount = count(array_filter($checks, fn($c) => $c['status'] === 'warn'));
$basePath  = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
if ($basePath === '.' || $basePath === '') $basePath = '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Kesiapan Sistem - Tahfidz Restu 2</title>
    <style>
        body { font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; background: #f8fafc; color: #1e293b; margin: 0; padding: 24px; }
        .card { max-width: 820px; margin: 0 auto; background: #fff; border-radius: 14px; padding: 28px; box-shadow: 0 4px 20px rgba(15,23,42,.06); border: 1px solid #e2e8f0; }
        h1 { margin: 0 0 6px; font-size: 22px; }
        .sub { color: #64748b; font-size: 14px; margin: 0 0 20px; }
        .banner { padding: 14px 16px; border-radius: 10px; margin-bottom: 20px; font-weight: 600; font-size: 14px; }
        .banner.ok   { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        .banner.fail { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid #f1f5f9; vertical-align: top; }
        th { color: #475569; font-weight: 600; background: #f8fafc; }
        .badge { display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: 12px; font-weight: 600; white-space: nowrap; }
        .badge.ok   { background: #dcfce7; color: #166534; }
        .badge.warn { background: #fef9c3; color: #854d0e; }
        .badge.fail { background: #fee2e2; color: #991b1b; }
        .actions { margin-top: 22px; display: flex; gap: 10px; flex-wrap: wrap; }
        .btn { display: inline-block; padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px; }
        .btn-primary { background: #059669; color: #fff; }
        .btn-secondary { background: #e2e8f0; color: #1e293b; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Cek Kesiapan Sistem Tahfidz</h1>
        <p class="sub">Pastikan seluruh pemeriksaan wajib berstatus OK sebelum menggunakan aplikasi.</p>

        <?php if ($failCount === 0): ?>
            <div class="banner ok">
                Semua pemeriksaan wajib berhasil! Sistem siap digunakan.
                <?php if ($warnCount > 0) echo " (Ada {$warnCount} peringatan ringan yang bisa diperhatikan.)"; ?>
            </div>
        <?php else: ?>
            <div class="banner fail">
                Ditemukan <?= $failCount ?> masalah yang harus diperbaiki sebelum sistem bisa berjalan normal.
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th style="width: 34%">Komponen</th>
                    <th style="width: 14%">Status</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($checks as $c): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($c['label']) ?></strong></td>
                        <td>
                            <?php if ($c['status'] === 'ok'): ?>
                                <span class="badge ok">OK</span>
                            <?php elseif ($c['status'] === 'warn'): ?>
                                <span class="badge warn">PERHATIAN</span>
                            <?php else: ?>
                                <span class="badge fail">GAGAL</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($c['detail']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="actions">
            <a class="btn btn-primary" href="<?= htmlspecialchars($basePath . '/') ?>">Buka Halaman Login &rarr;</a>
            <a class="btn btn-secondary" href="<?= htmlspecialchars($basePath . '/setup.php') ?>">Jalankan Ulang setup.php</a>
            <a class="btn btn-secondary" href="">Muat Ulang Cek</a>
        </div>
    </div>
</body>
</html>
