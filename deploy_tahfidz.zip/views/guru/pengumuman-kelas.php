<?php require_once __DIR__ . '/../../config/view_auth.php'; requireAnyRole(['guru', 'karyawan']); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Pengumuman Kelas - Tahfidz BA Restu Z</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                "colors": { "tertiary": "#003580","primary-fixed": "#a9f3be","on-primary": "#ffffff","primary": "#004323","error": "#ba1a1a","on-surface": "#191c1c","surface-bright": "#f8faf9","surface-container-lowest": "#ffffff","surface-container": "#eceeed","outline-variant": "#bfc9bf","on-surface-variant": "#404941","secondary": "#964900","secondary-container": "#fe8a29" },
                "borderRadius": {"DEFAULT": "1rem","lg": "1.5rem","full": "9999px"},
                "fontFamily": {"label-md": ["Plus Jakarta Sans"],"headline-sm": ["Plus Jakarta Sans"],"body-md": ["Plus Jakarta Sans"],"headline-md": ["Plus Jakarta Sans"]},
                "fontSize": { "label-md": ["14px",{"lineHeight":"20px","fontWeight":"600"}],"headline-sm": ["20px",{"lineHeight":"28px","fontWeight":"600"}],"body-md": ["16px",{"lineHeight":"24px","fontWeight":"400"}],"headline-md": ["24px",{"lineHeight":"32px","fontWeight":"700"}] }
            }}
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
    </style>
    <script src="../../assets/js/api.js?v=5"></script>
    <script src="../../assets/js/auth-guard.js?v=5"></script>
</head>
<body class="bg-surface-bright text-on-surface min-h-screen antialiased">
    <aside id="sidebar" class="fixed left-0 top-0 h-full w-72 bg-primary shadow-[40px_0_60px_-15px_rgba(0,67,35,0.15)] flex-col py-8 z-50 transform transition-transform duration-300 -translate-x-full md:translate-x-0 hidden md:flex overflow-y-auto"></aside>

    <main class="ml-0 md:ml-72 min-h-screen w-full md:w-[calc(100%-18rem)] pb-32">
        <header class="h-20 sticky top-0 z-40 bg-surface-bright/80 backdrop-blur-md shadow-sm flex justify-between items-center px-4 md:px-margin-desktop">
            <div class="flex items-center gap-3">
                <button id="mobile-menu-btn" class="md:hidden p-2 hover:bg-surface-container-high rounded-full transition-all text-on-surface-variant flex-shrink-0">
                    <span class="material-symbols-outlined">menu</span>
                </button>
                <!-- Desktop Collapse Button -->
                <button id="desktop-collapse-btn" class="hidden md:flex p-2 hover:bg-surface-container-high rounded-full transition-all text-on-surface-variant mr-2" title="Lipat Menu">
                    <span class="material-symbols-outlined">menu_open</span>
                </button>
                <h2 class="font-headline-sm text-headline-sm font-bold">Pengumuman Kelas</h2>
            </div>
            <div class="flex items-center gap-2 md:gap-4">
                <div class="flex items-center gap-2 md:gap-3">
                    <div class="text-right hidden sm:block">
                        <p class="font-label-md text-label-md text-on-surface" id="header-nama">-</p>
                        <p class="text-[12px] text-on-surface-variant">Wali Kelas</p>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-primary-fixed flex items-center justify-center text-primary font-bold text-sm border-2 border-primary-fixed" id="header-initials">-</div>
                </div>
                <button onclick="authGuard.logout()" class="bg-error text-on-error px-4 py-2 rounded-full text-xs md:text-sm font-bold active:opacity-80 transition-all ml-1 md:ml-2">Logout</button>
            </div>
        </header>

        <div class="p-4 md:p-12">
            <div class="mb-8">
                <p class="font-body-md text-body-md text-on-surface-variant">Daftar pengumuman dari Admin yang ditujukan untuk kelas Anda</p>
            </div>

            <div id="pengumuman-container" class="space-y-6">
                <div class="bg-white rounded-lg shadow-sm p-8 text-center text-on-surface-variant">Memuat pengumuman...</div>
            </div>
        </div>
    </main>

    <script>
    document.addEventListener('DOMContentLoaded', async () => {
        const user = await authGuard.protect('guru');
        if (!user) return;
        authGuard.initUserData(user);



        try {
            const res = await api.get('/api/guru/pengumuman.php');
            const container = document.getElementById('pengumuman-container');

            if (res.data && res.data.length > 0) {
                container.innerHTML = res.data.map(p => `
                    <div class="bg-white rounded-lg shadow-sm border-l-4 border-primary p-4 md:p-6">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-3 gap-1">
                            <h3 class="font-headline-sm text-headline-sm text-on-surface">${p.judul}</h3>
                            <span class="text-label-md text-on-surface-variant">${api.formatDate(p.created_at)}</span>
                        </div>
                        <p class="font-body-md text-body-md text-on-surface-variant">${p.isi}</p>
                    </div>
                `).join('');
            } else {
                container.innerHTML = '<div class="bg-white rounded-lg shadow-sm p-8 text-center text-on-surface-variant">Belum ada pengumuman untuk kelas Anda.</div>';
            }
        } catch (err) {
            console.error(err);
        }
    });
    </script>
</body>
</html>
