<?php require_once __DIR__ . '/../../config/view_auth.php'; requireRole('admin'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Dashboard Utama Admin - Tahfidz BA Restu Z</title>
    <meta name="description" content="Dashboard utama administrator sistem Tahfidz BA.">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                "colors": { "tertiary": "#003580","primary-fixed": "#a9f3be","on-primary": "#ffffff","surface-tint": "#226b41","surface-bright": "#f8faf9","on-primary-container": "#8ad2a0","secondary-container": "#fe8a29","secondary-fixed-dim": "#ffb786","surface-dim": "#d8dada","surface-container-highest": "#e1e3e2","primary": "#004323","error": "#ba1a1a","on-tertiary-container": "#aac1ff","on-surface": "#191c1c","inverse-surface": "#2e3131","primary-fixed-dim": "#8dd6a3","on-secondary": "#ffffff","surface": "#f8faf9","secondary-fixed": "#ffdcc6","surface-container-high": "#e6e9e8","on-surface-variant": "#404941","outline": "#707a70","on-tertiary-fixed-variant": "#00429c","on-secondary-fixed": "#311300","error-container": "#ffdad6","tertiary-fixed": "#d9e2ff","tertiary-fixed-dim": "#b0c6ff","on-tertiary-fixed": "#001945","background": "#f8faf9","tertiary-container": "#004aae","secondary": "#964900","surface-container-lowest": "#ffffff","on-secondary-container": "#642f00","surface-container-low": "#f2f4f3","on-tertiary": "#ffffff","surface-container": "#eceeed","on-error": "#ffffff","inverse-primary": "#8dd6a3","on-primary-fixed": "#00210e","on-background": "#191c1c","on-secondary-fixed-variant": "#723600","on-primary-fixed-variant": "#00522c","on-error-container": "#93000a","surface-variant": "#e1e3e2","primary-container": "#0d5c34","outline-variant": "#bfc9bf","inverse-on-surface": "#eff1f0" },
                "borderRadius": {"DEFAULT": "1rem","lg": "2rem","xl": "3rem","full": "9999px"},
                "spacing": {"base": "8px","margin-mobile": "16px","container-padding-sm": "16px","container-padding-md": "24px","margin-desktop": "48px","gutter": "20px"},
                "fontFamily": {"label-md": ["Plus Jakarta Sans"],"headline-sm": ["Plus Jakarta Sans"],"body-md": ["Plus Jakarta Sans"],"body-lg": ["Plus Jakarta Sans"],"headline-lg": ["Plus Jakarta Sans"],"headline-md": ["Plus Jakarta Sans"]},
                "fontSize": { "label-md": ["14px",{"lineHeight":"20px","fontWeight":"600"}],"headline-sm": ["20px",{"lineHeight":"28px","fontWeight":"600"}],"body-md": ["16px",{"lineHeight":"24px","fontWeight":"400"}],"body-lg": ["18px",{"lineHeight":"26px","fontWeight":"500"}],"headline-lg": ["32px",{"lineHeight":"40px","letterSpacing":"-0.02em","fontWeight":"700"}],"headline-md": ["24px",{"lineHeight":"32px","letterSpacing":"-0.01em","fontWeight":"700"}] }
            }}
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        .bg-mesh-accent { background-image: radial-gradient(at 0% 0%, rgba(0,67,35,0.05) 0px, transparent 50%), radial-gradient(at 100% 0%, rgba(0,53,128,0.05) 0px, transparent 50%), radial-gradient(at 100% 100%, rgba(150,73,0,0.05) 0px, transparent 50%); }
    </style>
    <script src="../../assets/js/api.js?v=5"></script>
    <script src="../../assets/js/auth-guard.js?v=5"></script>
</head>
<body class="bg-surface-bright text-on-surface bg-mesh-accent min-h-screen">
    <!-- Sidebar -->
    <aside id="sidebar" class="hidden md:flex flex-col h-screen w-72 fixed left-0 top-0 bg-primary shadow-[40px_0_60px_-15px_rgba(0,67,35,0.15)] z-50 py-8 transform transition-transform duration-300 -translate-x-full md:translate-x-0 overflow-y-auto">
    </aside>

    <!-- Header -->
    <header class="h-20 w-full md:w-[calc(100%-18rem)] sticky top-0 z-40 bg-surface-bright/80 backdrop-blur-md shadow-sm flex justify-between items-center px-4 md:px-margin-desktop md:ml-72">
        <div class="flex items-center gap-3">
            <!-- Mobile Menu Button -->
            <button id="mobile-menu-btn" class="md:hidden p-2 hover:bg-surface-container-high rounded-full transition-all text-on-surface-variant">
                <span class="material-symbols-outlined">menu</span>
            </button>
            <!-- Desktop Collapse Button -->
            <button id="desktop-collapse-btn" class="hidden md:flex p-2 hover:bg-surface-container-high rounded-full transition-all text-on-surface-variant mr-2" title="Lipat Menu">
                <span class="material-symbols-outlined">menu_open</span>
            </button>
            <h2 class="font-headline-sm text-headline-sm font-bold text-on-surface">Admin Dashboard</h2>
        </div>
        <div class="flex items-center gap-4">
            <div class="flex items-center gap-3">
                <div class="text-right hidden sm:block">
                    <p class="font-label-md text-label-md text-tertiary">Super Admin</p>
                    <p id="last-update" class="text-[12px] text-on-surface-variant">Memuat...</p>
                </div>
                <div class="w-10 h-10 rounded-full border-2 border-primary-fixed bg-surface-container flex items-center justify-center">
                    <span class="material-symbols-outlined text-primary">admin_panel_settings</span>
                </div>
            </div>
        </div>
    </header>

    <!-- Main -->
    <main class="ml-0 md:ml-72 p-6 md:p-margin-desktop pb-32 min-h-[calc(100vh-80px)] w-full md:w-[calc(100%-18rem)]">
        <!-- Metrics -->
        <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12" id="kpi-cards">

            <!-- Card 1: Total Siswa -->
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-primary flex items-center gap-5 hover:shadow-md transition-all duration-200 group cursor-default">
                <div class="w-14 h-14 bg-primary/10 text-primary rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-primary group-hover:text-white transition-all duration-200">
                    <span class="material-symbols-outlined text-[28px]">group</span>
                </div>
                <div>
                    <p class="text-on-surface-variant text-label-md font-label-md mb-1">Total Siswa</p>
                    <p class="text-headline-md font-headline-md text-on-surface leading-none" id="kpi-total-siswa">
                        <span class="inline-block w-16 h-7 bg-surface-container-high rounded animate-pulse"></span>
                    </p>
                    <p class="text-[11px] text-on-surface-variant mt-1">Siswa aktif terdaftar</p>
                </div>
            </div>

            <!-- Card 2: Total Kelas -->
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-tertiary flex items-center gap-5 hover:shadow-md transition-all duration-200 group cursor-default">
                <div class="w-14 h-14 bg-tertiary/10 text-tertiary rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-tertiary group-hover:text-white transition-all duration-200">
                    <span class="material-symbols-outlined text-[28px]">class</span>
                </div>
                <div>
                    <p class="text-on-surface-variant text-label-md font-label-md mb-1">Total Kelas</p>
                    <p class="text-headline-md font-headline-md text-on-surface leading-none" id="kpi-total-kelas">
                        <span class="inline-block w-12 h-7 bg-surface-container-high rounded animate-pulse"></span>
                    </p>
                    <p class="text-[11px] text-on-surface-variant mt-1">Kelas aktif berjalan</p>
                </div>
            </div>

            <!-- Card 3: Guru Mengampu -->
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-primary flex items-center gap-5 hover:shadow-md transition-all duration-200 group cursor-default">
                <div class="w-14 h-14 bg-primary/10 text-primary rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-primary group-hover:text-white transition-all duration-200">
                    <span class="material-symbols-outlined text-[28px]">badge</span>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-on-surface-variant text-label-md font-label-md mb-1">Guru Mengampu</p>
                    <p class="text-headline-md font-headline-md text-on-surface leading-none" id="kpi-guru-mengampu">
                        <span class="inline-block w-20 h-7 bg-surface-container-high rounded animate-pulse"></span>
                    </p>
                    <div class="mt-2 w-full h-1.5 bg-surface-container-high rounded-full overflow-hidden">
                        <div id="kpi-guru-bar" class="h-full bg-primary rounded-full transition-all duration-700" style="width:0%"></div>
                    </div>
                    <p class="text-[11px] text-on-surface-variant mt-1" id="kpi-guru-sub">dari total guru aktif</p>
                </div>
            </div>

            <!-- Card 4: Target Hafalan -->
            <div class="bg-white p-6 rounded-lg shadow-sm border-l-4 border-secondary flex items-center gap-5 hover:shadow-md transition-all duration-200 group cursor-default">
                <div class="w-14 h-14 bg-secondary/10 text-secondary rounded-full flex items-center justify-center flex-shrink-0 group-hover:bg-secondary group-hover:text-white transition-all duration-200">
                    <span class="material-symbols-outlined text-[28px]">menu_book</span>
                </div>
                <div>
                    <p class="text-on-surface-variant text-label-md font-label-md mb-1">Target Hafalan</p>
                    <p class="text-headline-md font-headline-md text-on-surface leading-none" id="kpi-target-hafalan">
                        <span class="inline-block w-14 h-7 bg-surface-container-high rounded animate-pulse"></span>
                    </p>
                    <p class="text-[11px] text-on-surface-variant mt-1">Tugas terpublikasikan</p>
                </div>
            </div>

        </section>

        <!-- Classes Grid -->
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-headline-sm font-headline-sm text-on-surface">Monitoring Kelas (Bulan Ini)</h3>
            <div class="flex gap-2">
            </div>
        </div>
        <section class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-gutter" id="kelas-grid">
            <!-- Kelas dimuat dari API -->
            <div class="col-span-full text-center py-12 text-on-surface-variant">
                <span class="material-symbols-outlined text-[48px] mb-2 block">hourglass_empty</span>
                Memuat data kelas...
            </div>
        </section>

        <!-- Widget: Log Aktivitas Login Hari Ini -->
        <div class="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div class="lg:col-span-1 bg-white p-6 rounded-lg shadow-sm border border-outline-variant/20 flex flex-col gap-4">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 bg-tertiary/10 rounded-lg flex items-center justify-center">
                            <span class="material-symbols-outlined text-tertiary" style="font-variation-settings:'FILL' 1;">manage_history</span>
                        </div>
                        <div>
                            <p class="font-semibold text-on-surface text-sm">Login Hari Ini</p>
                            <p class="text-[11px] text-on-surface-variant" id="login-log-date">-</p>
                        </div>
                    </div>
                    <a href="log-login.php" class="text-xs text-tertiary font-semibold hover:underline flex items-center gap-1">
                        Detail <span class="material-symbols-outlined text-sm">arrow_forward</span>
                    </a>
                </div>
                <div class="grid grid-cols-3 gap-3">
                    <div class="bg-green-50 rounded-lg p-3 text-center">
                        <p class="text-2xl font-bold text-green-700" id="log-berhasil">-</p>
                        <p class="text-[10px] text-green-600 font-medium">Berhasil</p>
                    </div>
                    <div class="bg-red-50 rounded-lg p-3 text-center">
                        <p class="text-2xl font-bold text-red-700" id="log-gagal">-</p>
                        <p class="text-[10px] text-red-600 font-medium">Gagal</p>
                    </div>
                    <div class="bg-blue-50 rounded-lg p-3 text-center">
                        <p class="text-2xl font-bold text-blue-700" id="log-unik">-</p>
                        <p class="text-[10px] text-blue-600 font-medium">User Unik</p>
                    </div>
                </div>
                <div id="log-gagal-alert" class="hidden bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2">
                    <span class="material-symbols-outlined text-red-500 text-sm flex-shrink-0 mt-0.5" style="font-variation-settings:'FILL' 1;">warning</span>
                    <p class="text-xs text-red-700" id="log-gagal-text"></p>
                </div>
            </div>
            <div class="lg:col-span-2 bg-white p-6 rounded-lg shadow-sm border border-outline-variant/20">
                <p class="font-semibold text-on-surface text-sm mb-4">5 Login Terakhir</p>
                <div id="log-recent" class="space-y-2">
                    <div class="text-center text-on-surface-variant text-sm py-4">Memuat...</div>
                </div>
            </div>
        </div>

        <!-- Content Banner -->
        <div class="mt-12 p-8 bg-primary rounded-lg relative overflow-hidden flex flex-col md:flex-row items-center justify-between text-white shadow-2xl">
            <div class="z-10 relative">
                <h3 class="text-headline-md font-headline-md mb-2">Pantau Setoran Real-time</h3>
                <p class="text-body-md opacity-80 max-w-lg mb-6">Sistem terintegrasi untuk memudahkan guru dan administrator dalam memonitoring hafalan siswa setiap hari.</p>
                <div class="flex gap-4">
                    <a href="laporan.php" class="bg-white text-primary px-6 py-3 rounded-full font-bold hover:bg-surface-container transition-all inline-block">Unduh Laporan</a>
                </div>
            </div>
            <div class="absolute right-0 top-0 w-full h-full opacity-20 pointer-events-none">
                <svg height="100%" width="100%">
                    <pattern height="60" id="pattern-waves" patternUnits="userSpaceOnUse" width="100" x="0" y="0">
                        <path d="M0 30 Q 25 10 50 30 Q 75 50 100 30" fill="none" stroke="white" stroke-width="2"></path>
                    </pattern>
                    <rect fill="url(#pattern-waves)" height="100%" width="100%"></rect>
                </svg>
            </div>
        </div>
    </main>

    <!-- Mobile Bottom Navigation -->
    <nav class="fixed bottom-0 w-full md:hidden bg-surface-container-lowest border-t border-outline-variant shadow-[0_-4px_20px_0_rgba(0,0,0,0.05)] z-50 flex justify-around items-center h-16">
        <a class="text-primary font-bold flex flex-col items-center justify-center p-2" href="#">
            <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">dashboard</span>
            <span class="text-label-md text-[10px]">Home</span>
        </a>
        <a class="text-on-surface-variant flex flex-col items-center justify-center p-2" href="manajemen-pengguna.php">
            <span class="material-symbols-outlined">person_4</span>
            <span class="text-label-md text-[10px]">Users</span>
        </a>
        <a class="text-on-surface-variant flex flex-col items-center justify-center p-2" href="komando.php">
            <span class="material-symbols-outlined">campaign</span>
            <span class="text-label-md text-[10px]">Info</span>
        </a>
    </nav>
    <script>
    let lastUpdate = null;

    async function loadDashboard() {
        try {
            const res = await api.get('/api/admin/dashboard-stats.php');
            const d = res.data;

            // --- KPI Card 1: Total Siswa ---
            document.getElementById('kpi-total-siswa').textContent = d.total_siswa ?? '-';

            // --- KPI Card 2: Total Kelas ---
            document.getElementById('kpi-total-kelas').textContent = d.total_kelas ?? '-';

            // --- KPI Card 3: Guru Mengampu ---
            const mengampu = d.guru_mengampu ?? 0;
            const totalGuru = d.total_guru ?? 0;
            document.getElementById('kpi-guru-mengampu').textContent = `${mengampu} / ${totalGuru}`;
            const pctGuru = totalGuru > 0 ? Math.round((mengampu / totalGuru) * 100) : 0;
            // Animasi bar setelah render
            requestAnimationFrame(() => {
                document.getElementById('kpi-guru-bar').style.width = pctGuru + '%';
            });
            document.getElementById('kpi-guru-sub').textContent = `${pctGuru}% dari ${totalGuru} guru aktif`;

            // --- KPI Card 4: Target Hafalan ---
            document.getElementById('kpi-target-hafalan').textContent = d.total_target_hafalan ?? '-';

            // Render class grid
            const grid = document.getElementById('kelas-grid');
            if (d.kelas && d.kelas.length > 0) {
                grid.innerHTML = d.kelas.map(k => {
                    const pct = k.total_siswa > 0 ? Math.round((k.sudah_kumpul / k.total_siswa) * 100) : 0;
                    const colorClass = pct >= 80 ? 'text-tertiary' : pct >= 50 ? 'text-secondary' : 'text-error';
                    return `
                    <div class="bg-white p-6 rounded-lg shadow-[0_10px_25px_-5px_rgba(0,0,0,0.05)] border border-transparent hover:border-tertiary/20 transition-all group">
                        <div class="flex justify-between items-start mb-6">
                            <div class="bg-primary/5 p-3 rounded-lg group-hover:bg-primary transition-colors">
                                <span class="material-symbols-outlined text-primary group-hover:text-white">room_preferences</span>
                            </div>
                            <span class="bg-primary-fixed-dim/20 text-on-primary-fixed-variant px-3 py-1 rounded-full text-[12px] font-bold">${k.kode_kelas}</span>
                        </div>
                        <h4 class="text-body-lg font-bold text-on-surface mb-1">${k.nama_kelas}</h4>
                        <p class="text-label-md text-on-surface-variant mb-4">${k.nama_guru || '-'}</p>
                        <div class="mb-6">
                            <div class="flex justify-between text-[12px] mb-2 font-bold">
                                <span class="${colorClass}">Progress Setoran</span>
                                <span class="${colorClass}">${pct}%</span>
                            </div>
                            <div class="w-full h-2 bg-surface-container rounded-full overflow-hidden">
                                <div class="h-full bg-tertiary" style="width:${pct}%"></div>
                            </div>
                        </div>
                        <a href="monitor-kelas.php?kelas_id=${k.kelas_id}" class="w-full bg-secondary-container text-on-secondary-container py-3 rounded-lg font-bold flex items-center justify-center gap-2 hover:shadow-lg transition-all active:scale-95 text-center">
                            Intip Kelas <span class="material-symbols-outlined text-[18px]">arrow_forward</span>
                        </a>
                    </div>`;
                }).join('');
            }

            // Update timestamp
            lastUpdate = new Date();
            const timeStr = lastUpdate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
            const el = document.getElementById('last-update');
            if (el) el.textContent = `Terakhir diperbarui: ${timeStr}`;
        } catch (err) {
            console.error('Gagal memuat dashboard:', err);
        }
    }

    document.addEventListener('DOMContentLoaded', async () => {
        const user = await authGuard.protect('admin');
        if (!user) return;
        
        await loadDashboard();
        loadLoginWidget();
        
        // Auto-refresh setiap 60 detik
        setInterval(loadDashboard, 60000);
        setInterval(loadLoginWidget, 120000);
    });

    async function loadLoginWidget() {
        try {
            const today = new Date().toISOString().split('T')[0];
            const res = await api.get(`/api/admin/log-login.php?tanggal_dari=${today}&tanggal_sampai=${today}&per_page=5`);
            const { summary, logs } = res.data;

            // Update statistik
            document.getElementById('log-berhasil').textContent = summary.berhasil ?? 0;
            document.getElementById('log-gagal').textContent    = summary.gagal    ?? 0;
            document.getElementById('log-unik').textContent     = summary.unik_user ?? 0;
            document.getElementById('login-log-date').textContent =
                new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' });

            // Peringatan jika banyak gagal
            const alertEl = document.getElementById('log-gagal-alert');
            const alertTx = document.getElementById('log-gagal-text');
            if (summary.gagal >= 3) {
                alertEl.classList.remove('hidden');
                alertTx.textContent = `${summary.gagal} percobaan login gagal terdeteksi hari ini. Periksa log untuk detail.`;
            } else {
                alertEl.classList.add('hidden');
            }

            // 5 login terakhir
            const recentEl = document.getElementById('log-recent');
            if (!logs || logs.length === 0) {
                recentEl.innerHTML = '<div class="text-center text-on-surface-variant text-sm py-4">Belum ada aktivitas login hari ini.</div>';
                return;
            }

            const roleLabel = { admin: 'Admin', guru: 'Guru', karyawan: 'Karyawan', wali_murid: 'Wali Murid' };
            recentEl.innerHTML = logs.slice(0, 5).map(l => {
                const waktu = new Date(l.created_at.replace(' ', 'T'));
                const jam   = waktu.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
                const isOk  = l.status === 'berhasil';
                return `<div class="flex items-center gap-3 py-2 border-b border-outline-variant/20 last:border-0">
                    <span class="material-symbols-outlined text-sm ${isOk ? 'text-green-600' : 'text-red-500'}" style="font-variation-settings:'FILL' 1;">${isOk ? 'check_circle' : 'cancel'}</span>
                    <div class="flex-1 min-w-0">
                        <p class="text-sm font-medium text-on-surface truncate">${l.nama || l.nomor_identitas}</p>
                        <p class="text-[11px] text-on-surface-variant">${roleLabel[l.role] || '-'}</p>
                    </div>
                    <div class="text-right flex-shrink-0">
                        <p class="text-xs text-on-surface-variant">${jam}</p>
                        <p class="text-[10px] ${isOk ? 'text-green-600' : 'text-red-500'} font-medium">${isOk ? 'Berhasil' : 'Gagal'}</p>
                    </div>
                </div>`;
            }).join('');
        } catch(e) {
            console.warn('Widget log login gagal dimuat:', e);
        }
    }
    </script>
</body>
</html>

