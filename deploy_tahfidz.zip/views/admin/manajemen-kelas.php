<?php require_once __DIR__ . '/../../config/view_auth.php'; requireRole('admin'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kelas - Tahfidz BA Admin</title>
    <meta name="description" content="Kelola data kelas tahfidz TKA dan TKB, kelas intensif, dan koordinator.">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                "colors": {"tertiary":"#003580","primary-fixed":"#a9f3be","on-primary":"#ffffff","surface-tint":"#226b41","surface-bright":"#f8faf9","on-primary-container":"#8ad2a0","secondary-container":"#fe8a29","secondary-fixed-dim":"#ffb786","surface-dim":"#d8dada","surface-container-highest":"#e1e3e2","primary":"#004323","error":"#ba1a1a","on-tertiary-container":"#aac1ff","on-surface":"#191c1c","inverse-surface":"#2e3131","primary-fixed-dim":"#8dd6a3","on-secondary":"#ffffff","surface":"#f8faf9","secondary-fixed":"#ffdcc6","surface-container-high":"#e6e9e8","on-surface-variant":"#404941","outline":"#707a70","on-tertiary-fixed-variant":"#00429c","on-secondary-fixed":"#311300","error-container":"#ffdad6","tertiary-fixed":"#d9e2ff","tertiary-fixed-dim":"#b0c6ff","on-tertiary-fixed":"#001945","background":"#f8faf9","tertiary-container":"#004aae","secondary":"#964900","surface-container-lowest":"#ffffff","on-secondary-container":"#642f00","surface-container-low":"#f2f4f3","on-tertiary":"#ffffff","surface-container":"#eceeed","on-error":"#ffffff","inverse-primary":"#8dd6a3","on-primary-fixed":"#00210e","on-background":"#191c1c","on-secondary-fixed-variant":"#723600","on-primary-fixed-variant":"#00522c","on-error-container":"#93000a","surface-variant":"#e1e3e2","primary-container":"#0d5c34","outline-variant":"#bfc9bf","inverse-on-surface":"#eff1f0"},
                "fontFamily": {"sans": ["Plus Jakarta Sans","sans-serif"]}
            }}
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f8faf9; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
        .badge-intensif    { background: linear-gradient(135deg, #7c3aed, #4f46e5); color: white; }
        .badge-koordinator { background: linear-gradient(135deg, #dc2626, #b91c1c); color: white; }
        .badge-reguler     { background: #dcfce7; color: #166534; }
        .badge-kb          { background: #dbeafe; color: #1e40af; }
        @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
        .card-enter { animation: fadeIn 0.25s ease forwards; }
    </style>
    <script src="../../assets/js/api.js?v=5"></script>
    <script src="../../assets/js/auth-guard.js?v=5"></script>
</head>
<body class="bg-surface-bright text-on-surface antialiased">

    <aside id="sidebar" class="fixed left-0 top-0 h-full w-72 bg-primary shadow-[40px_0_60px_-15px_rgba(0,67,35,0.15)] flex-col py-8 z-50 transform transition-transform duration-300 -translate-x-full md:translate-x-0 hidden md:flex overflow-y-auto"></aside>

    <header class="h-20 w-full md:w-[calc(100%-18rem)] sticky top-0 z-40 bg-surface-bright/80 backdrop-blur-md shadow-sm flex justify-between items-center px-4 md:px-12 ml-0 md:ml-72">
        <div class="flex items-center gap-3">
            <button id="mobile-menu-btn" class="md:hidden p-2 hover:bg-surface-container-high rounded-full text-on-surface-variant">
                <span class="material-symbols-outlined">menu</span>
            </button>
            <button id="desktop-collapse-btn" class="hidden md:flex p-2 hover:bg-surface-container-high rounded-full text-on-surface-variant mr-2">
                <span class="material-symbols-outlined">menu_open</span>
            </button>
            <h2 class="font-bold text-xl text-on-surface">Manajemen Kelas</h2>
        </div>
        <button onclick="openTambahModal()" id="btn-tambah-kelas" class="flex items-center gap-2 px-5 py-2.5 bg-secondary-container text-white font-bold rounded-xl shadow-lg hover:brightness-105 active:scale-95 transition-all text-sm">
            <span class="material-symbols-outlined text-base">add</span>
            Tambah Kelas
        </button>
    </header>

    <main class="ml-0 md:ml-72 p-4 md:p-12 pb-32 w-full md:w-[calc(100%-18rem)]">

        <!-- Stats Row -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8" id="stats-row">
            <div class="bg-white rounded-2xl border border-outline-variant/40 p-5 shadow-sm">
                <p class="text-xs font-semibold text-on-surface-variant mb-1">Total Kelas Aktif</p>
                <p class="text-3xl font-black text-primary" id="stat-total">-</p>
            </div>
            <div class="bg-white rounded-2xl border border-outline-variant/40 p-5 shadow-sm">
                <p class="text-xs font-semibold text-on-surface-variant mb-1">Kelas TKA</p>
                <p class="text-3xl font-black text-tertiary" id="stat-tka">-</p>
            </div>
            <div class="bg-white rounded-2xl border border-outline-variant/40 p-5 shadow-sm">
                <p class="text-xs font-semibold text-on-surface-variant mb-1">Kelas TKB</p>
                <p class="text-3xl font-black text-tertiary" id="stat-tkb">-</p>
            </div>
            <div class="bg-gradient-to-br from-violet-600 to-indigo-600 rounded-2xl p-5 shadow-sm">
                <p class="text-xs font-semibold text-violet-100 mb-1">Kelas Intensif</p>
                <p class="text-3xl font-black text-white" id="stat-intensif">-</p>
            </div>
        </div>

        <!-- Filter Pills -->
        <div class="flex gap-2 mb-6 flex-wrap">
            <button onclick="setFilter('all')" id="filter-all" class="filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-primary bg-primary text-white transition-all">Semua</button>
            <button onclick="setFilter('TKA')" id="filter-TKA" class="filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-outline-variant text-on-surface-variant hover:border-primary hover:text-primary transition-all">TKA</button>
            <button onclick="setFilter('TKB')" id="filter-TKB" class="filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-outline-variant text-on-surface-variant hover:border-primary hover:text-primary transition-all">TKB</button>
            <button onclick="setFilter('TPA')" id="filter-TPA" class="filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-outline-variant text-on-surface-variant hover:border-primary hover:text-primary transition-all">TPA</button>
            <button onclick="setFilter('KB')" id="filter-KB" class="filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-outline-variant text-on-surface-variant hover:border-primary hover:text-primary transition-all">KB</button>
            <div class="flex-1"></div>
            <div class="relative">
                <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-on-surface-variant text-base">search</span>
                <input type="text" id="search-kelas" oninput="renderGrid()" placeholder="Cari kelas..." class="pl-9 pr-4 py-2 border border-outline-variant rounded-full text-sm bg-white focus:ring-2 focus:ring-primary/30 w-52">
            </div>
        </div>

        <!-- Kelas Grid -->
        <div id="kelas-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            <div class="col-span-full py-16 text-center text-on-surface-variant">
                <span class="material-symbols-outlined text-5xl opacity-30 animate-spin">refresh</span>
                <p class="mt-2 text-sm">Memuat data kelas...</p>
            </div>
        </div>

    </main>

    <!-- =================== TAMBAH / EDIT MODAL =================== -->
    <div id="form-modal" class="fixed inset-0 bg-black/50 z-50 hidden items-center justify-center p-4">
        <div class="bg-white rounded-3xl w-full max-w-md p-8 shadow-2xl relative border border-gray-100 max-h-[90vh] overflow-y-auto">
            <div class="flex items-center gap-4 mb-6">
                <div class="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                    <span class="material-symbols-outlined text-primary text-2xl">meeting_room</span>
                </div>
                <div>
                    <h3 id="modal-title" class="font-bold text-xl text-on-surface">Tambah Kelas Baru</h3>
                    <p class="text-sm text-on-surface-variant">Isi data kelas di bawah ini</p>
                </div>
                <button onclick="closeModal()" class="ml-auto p-2 hover:bg-surface-container rounded-full text-on-surface-variant">
                    <span class="material-symbols-outlined">close</span>
                </button>
            </div>

            <input type="hidden" id="edit-id">

            <div class="space-y-4 text-sm font-semibold text-gray-700">
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block mb-1 text-xs">Kode Kelas <span class="text-error">*</span></label>
                        <input type="text" id="f-kode" placeholder="Misal: TKA-INT" maxlength="10"
                            class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal uppercase">
                        <p class="text-[11px] text-on-surface-variant mt-1">Kode unik, tidak bisa diubah</p>
                    </div>
                    <div>
                        <label class="block mb-1 text-xs">Tahun Ajaran</label>
                        <input type="text" id="f-tahun" value="2025/2026" placeholder="2025/2026"
                            class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal">
                    </div>
                </div>

                <div>
                    <label class="block mb-1 text-xs">Nama Kelas <span class="text-error">*</span></label>
                    <input type="text" id="f-nama" placeholder="Misal: Kelas Intensif TKA"
                        class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block mb-1 text-xs">Jenjang <span class="text-error">*</span></label>
                        <select id="f-jenjang" class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal">
                            <option value="TKA">TKA</option>
                            <option value="TKB">TKB</option>
                            <option value="TPA">TPA</option>
                        </select>
                    </div>
                    <div>
                        <label class="block mb-1 text-xs">Jenis Kelas</label>
                        <select id="f-jenis" class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal">
                            <option value="reguler">Reguler</option>
                            <option value="intensif">Intensif ⭐</option>
                            <option value="koordinator">Koordinator 👑</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label class="block mb-1 text-xs">Guru Pengampu</label>
                    <select id="f-guru" class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal">
                        <option value="">-- Belum Ditentukan --</option>
                    </select>
                </div>

                <div>
                    <label class="block mb-1 text-xs">Urutan Tampil</label>
                    <input type="number" id="f-urutan" value="5" min="1" max="99"
                        class="w-full py-2.5 px-3 bg-surface-container-low border border-outline-variant rounded-xl text-sm font-normal">
                    <p class="text-[11px] text-on-surface-variant mt-1">Angka kecil = muncul lebih awal</p>
                </div>

                <div id="field-aktif-wrapper" class="flex items-center justify-between p-3 bg-surface-container-low rounded-xl">
                    <span class="text-on-surface-variant">Kelas Aktif</span>
                    <input type="checkbox" id="f-aktif" checked class="rounded border-outline-variant text-primary focus:ring-primary w-5 h-5">
                </div>
            </div>

            <div class="flex gap-3 mt-6">
                <button onclick="closeModal()" class="flex-1 py-3 bg-surface-container-high text-on-surface rounded-xl font-bold hover:bg-surface-dim transition-colors">Batal</button>
                <button id="btn-simpan-modal" onclick="simpanKelas()" class="flex-[2] py-3 bg-primary text-white rounded-xl font-bold hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-lg">
                    <span class="material-symbols-outlined text-base">save</span>
                    Simpan
                </button>
            </div>
        </div>
    </div>

    <!-- =================== HAPUS CONFIRM MODAL =================== -->
    <div id="hapus-modal" class="fixed inset-0 bg-black/50 z-50 hidden items-center justify-center p-4">
        <div class="bg-white rounded-3xl w-full max-w-sm p-8 shadow-2xl">
            <div class="w-14 h-14 rounded-full bg-error-container/30 flex items-center justify-center mx-auto mb-4">
                <span class="material-symbols-outlined text-error text-3xl" style="font-variation-settings:'FILL' 1">warning</span>
            </div>
            <h3 class="font-bold text-xl text-center text-on-surface mb-2">Nonaktifkan Kelas?</h3>
            <p class="text-sm text-on-surface-variant text-center mb-1">Kelas <strong id="hapus-nama"></strong> akan dinonaktifkan.</p>
            <p class="text-xs text-on-surface-variant text-center mb-6">Data siswa tidak akan dihapus dan guru pengampu tetap terhubung. Kelas bisa diaktifkan kembali nanti.</p>
            <div class="flex gap-3">
                <button onclick="closeHapusModal()" class="flex-1 py-3 bg-surface-container-high rounded-xl font-bold text-on-surface">Batal</button>
                <button id="btn-konfirmasi-hapus" onclick="konfirmasiHapus()" class="flex-1 py-3 bg-error text-white rounded-xl font-bold hover:brightness-110 active:scale-95 transition-all">Nonaktifkan</button>
            </div>
        </div>
    </div>

    <!-- Mobile nav -->
    <nav class="fixed bottom-0 w-full md:hidden rounded-t-lg shadow-[0_-4px_20px_0_rgba(0,0,0,0.05)] bg-surface-container-lowest z-50 flex justify-around items-center h-16">
        <a class="text-on-surface-variant flex flex-col items-center justify-center p-2" href="dashboard.php">
            <span class="material-symbols-outlined">dashboard</span>
            <span class="text-[10px]">Home</span>
        </a>
        <a class="text-on-surface-variant flex flex-col items-center justify-center p-2" href="manajemen-pengguna.php">
            <span class="material-symbols-outlined">person_4</span>
            <span class="text-[10px]">Pengguna</span>
        </a>
        <a class="text-primary font-bold flex flex-col items-center justify-center p-2" href="#">
            <span class="material-symbols-outlined" style="font-variation-settings:'FILL' 1">meeting_room</span>
            <span class="text-[10px]">Kelas</span>
        </a>
    </nav>

    <script>
    let allKelas = [];
    let allGuru = [];
    let currentFilter = 'all';
    let hapusId = null;
    let isEditMode = false;

    const JENIS_BADGE = {
        intensif:    'badge-intensif',
        koordinator: 'badge-koordinator',
        reguler:     'badge-reguler',
    };
    const JENIS_LABEL = {
        intensif:    'Intensif ⭐',
        koordinator: 'Koordinator 👑',
        reguler:     'Reguler',
    };
    const JENJANG_COLOR = { TKA: 'text-primary', TKB: 'text-tertiary', KB: 'text-indigo-600', TPA: 'text-gray-500' };

    document.addEventListener('DOMContentLoaded', async () => {
        const user = await authGuard.protect('admin');
        if (!user) return;
        await loadData();
    });

    async function loadData() {
        try {
            const [resKelas, resGuru] = await Promise.all([
                api.get('/api/admin/daftar-kelas.php?include_tpa=1&all=1'),
                api.get('/api/admin/daftar-guru.php?per_page=100')
            ]);
            allKelas = resKelas.data || [];
            allGuru = (resGuru.data && Array.isArray(resGuru.data.data)) ? resGuru.data.data : [];
            updateStats();
            renderGrid();
            populateGuruDropdown();
        } catch (e) {
            document.getElementById('kelas-grid').innerHTML = `<div class="col-span-full py-12 text-center text-error text-sm">Gagal memuat data: ${e.message}</div>`;
        }
    }

    function updateStats() {
        const aktif = allKelas.filter(k => k.is_active == 1);
        document.getElementById('stat-total').textContent    = aktif.length;
        document.getElementById('stat-tka').textContent     = aktif.filter(k => k.jenjang === 'TKA').length;
        document.getElementById('stat-tkb').textContent     = aktif.filter(k => k.jenjang === 'TKB').length;
        document.getElementById('stat-intensif').textContent = aktif.filter(k => k.jenis_kelas === 'intensif' || k.jenis_kelas === 'koordinator').length;
    }

    function setFilter(f) {
        currentFilter = f;
        document.querySelectorAll('.filter-pill').forEach(b => {
            b.className = 'filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-outline-variant text-on-surface-variant hover:border-primary hover:text-primary transition-all';
        });
        const active = document.getElementById('filter-' + f);
        if (active) active.className = 'filter-pill px-4 py-2 rounded-full text-sm font-semibold border-2 border-primary bg-primary text-white transition-all';
        renderGrid();
    }

    function renderGrid() {
        const q = (document.getElementById('search-kelas')?.value || '').toLowerCase();
        let filtered = allKelas.filter(k => {
            if (currentFilter !== 'all' && k.jenjang !== currentFilter) return false;
            if (q && !k.nama_kelas.toLowerCase().includes(q) && !k.kode_kelas.toLowerCase().includes(q)) return false;
            return true;
        });

        const grid = document.getElementById('kelas-grid');
        if (filtered.length === 0) {
            grid.innerHTML = `<div class="col-span-full py-16 text-center text-on-surface-variant">
                <span class="material-symbols-outlined text-5xl opacity-30">search_off</span>
                <p class="mt-2 text-sm">Tidak ada kelas ditemukan</p>
            </div>`;
            return;
        }

        grid.innerHTML = filtered.map((k, i) => {
            const isAktif = k.is_active == 1;
            const jenisClass = JENIS_BADGE[k.jenis_kelas] || 'badge-reguler';
            const jenisLabel = JENIS_LABEL[k.jenis_kelas] || k.jenis_kelas;
            const jenjangColor = JENJANG_COLOR[k.jenjang] || 'text-on-surface';
            const siswaCount = parseInt(k.jumlah_siswa || 0);
            return `
            <div class="card-enter bg-white rounded-2xl border ${isAktif ? 'border-outline-variant/40' : 'border-dashed border-outline-variant opacity-60'} shadow-sm hover:shadow-md transition-all overflow-hidden" style="animation-delay:${i*40}ms">
                <!-- Top accent based on jenjang -->
                <div class="h-1.5 w-full ${k.jenjang === 'TKB' ? 'bg-tertiary' : k.jenjang === 'TKA' ? 'bg-primary' : 'bg-indigo-500'}"></div>
                <div class="p-5">
                    <div class="flex items-start justify-between mb-3">
                        <div>
                            <span class="text-xs font-bold ${jenjangColor} uppercase tracking-wider">${k.jenjang}</span>
                            <h4 class="font-bold text-on-surface text-base leading-tight mt-0.5">${k.nama_kelas}</h4>
                            <p class="text-xs text-on-surface-variant">${k.kode_kelas}</p>
                        </div>
                        <span class="px-2.5 py-1 rounded-full text-[11px] font-bold ${jenisClass}">${jenisLabel}</span>
                    </div>

                    <div class="space-y-2 text-xs text-on-surface-variant mb-4">
                        <div class="flex items-center gap-2">
                            <span class="material-symbols-outlined text-sm">person_4</span>
                            <span>${k.nama_guru || 'Belum ada guru'}</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="material-symbols-outlined text-sm">group</span>
                            <span>${siswaCount} siswa</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="material-symbols-outlined text-sm">calendar_today</span>
                            <span>TA ${k.tahun_ajaran || '-'}</span>
                        </div>
                    </div>

                    <div class="flex gap-2 pt-3 border-t border-outline-variant/30">
                        <button onclick="openEditModal(${k.id})" class="flex-1 py-2 bg-primary/10 text-primary rounded-lg text-xs font-bold hover:bg-primary/20 transition-colors flex items-center justify-center gap-1">
                            <span class="material-symbols-outlined text-sm">edit</span> Edit
                        </button>
                        ${isAktif ? `<button onclick="openHapusModal(${k.id}, '${k.nama_kelas.replace(/'/g,"\\'")}', ${siswaCount})" class="py-2 px-3 bg-error-container/20 text-error rounded-lg text-xs font-bold hover:bg-error-container/40 transition-colors flex items-center justify-center">
                            <span class="material-symbols-outlined text-sm">block</span>
                        </button>` : `<span class="py-2 px-3 bg-surface-container-highest text-on-surface-variant rounded-lg text-xs font-bold text-center">Nonaktif</span>`}
                    </div>
                </div>
            </div>`;
        }).join('');
    }

    function populateGuruDropdown(selectedId = null) {
        const sel = document.getElementById('f-guru');
        sel.innerHTML = '<option value="">-- Belum Ditentukan --</option>';
        allGuru.forEach(g => {
            const opt = document.createElement('option');
            opt.value = g.id;
            opt.textContent = g.nama_lengkap;
            if (selectedId && g.id == selectedId) opt.selected = true;
            sel.appendChild(opt);
        });
    }

    function openTambahModal() {
        isEditMode = false;
        document.getElementById('modal-title').textContent = 'Tambah Kelas Baru';
        document.getElementById('edit-id').value = '';
        document.getElementById('f-kode').value = '';
        document.getElementById('f-kode').disabled = false;
        document.getElementById('f-nama').value = '';
        document.getElementById('f-jenjang').value = 'TKA';
        document.getElementById('f-jenis').value = 'reguler';
        document.getElementById('f-tahun').value = '2025/2026';
        document.getElementById('f-urutan').value = '5';
        document.getElementById('f-aktif').checked = true;
        document.getElementById('field-aktif-wrapper').classList.add('hidden');
        populateGuruDropdown();
        document.getElementById('form-modal').classList.remove('hidden');
        document.getElementById('form-modal').classList.add('flex');
    }

    function openEditModal(id) {
        const kelas = allKelas.find(k => k.id == id);
        if (!kelas) return;
        isEditMode = true;
        document.getElementById('modal-title').textContent = 'Edit Kelas';
        document.getElementById('edit-id').value = id;
        document.getElementById('f-kode').value = kelas.kode_kelas;
        document.getElementById('f-kode').disabled = true; // kode tidak bisa diubah
        document.getElementById('f-nama').value = kelas.nama_kelas;
        document.getElementById('f-jenjang').value = kelas.jenjang;
        document.getElementById('f-jenis').value = kelas.jenis_kelas || 'reguler';
        document.getElementById('f-tahun').value = kelas.tahun_ajaran || '2025/2026';
        document.getElementById('f-urutan').value = kelas.urutan || 5;
        document.getElementById('f-aktif').checked = kelas.is_active == 1;
        document.getElementById('field-aktif-wrapper').classList.remove('hidden');
        populateGuruDropdown(kelas.guru_id);
        document.getElementById('form-modal').classList.remove('hidden');
        document.getElementById('form-modal').classList.add('flex');
    }

    function closeModal() {
        document.getElementById('form-modal').classList.add('hidden');
        document.getElementById('form-modal').classList.remove('flex');
    }

    async function simpanKelas() {
        const btn = document.getElementById('btn-simpan-modal');
        const nama  = document.getElementById('f-nama').value.trim();
        const kode  = document.getElementById('f-kode').value.trim().toUpperCase();
        const jenjang = document.getElementById('f-jenjang').value;
        const jenis   = document.getElementById('f-jenis').value;
        const tahun   = document.getElementById('f-tahun').value.trim();
        const urutan  = parseInt(document.getElementById('f-urutan').value) || 5;
        const guruId  = document.getElementById('f-guru').value || null;
        const aktif   = document.getElementById('f-aktif').checked ? 1 : 0;

        if (!nama || (!isEditMode && !kode) || !jenjang) {
            api.toast('Nama kelas dan jenjang wajib diisi!', 'error');
            return;
        }

        btn.disabled = true;
        btn.innerHTML = '<span class="material-symbols-outlined text-base animate-spin">refresh</span> Menyimpan...';

        try {
            if (isEditMode) {
                const id = document.getElementById('edit-id').value;
                await api.put(`/api/admin/edit-kelas.php?id=${id}`, {
                    nama_kelas: nama, jenis_kelas: jenis, jenjang: jenjang,
                    tahun_ajaran: tahun, urutan: urutan,
                    guru_id: guruId ? parseInt(guruId) : null,
                    is_active: aktif
                });
                api.toast('Kelas berhasil diperbarui!', 'success');
            } else {
                await api.post('/api/admin/tambah-kelas.php', {
                    kode_kelas: kode, nama_kelas: nama, jenjang: jenjang,
                    jenis_kelas: jenis, tahun_ajaran: tahun, urutan: urutan,
                    guru_id: guruId ? parseInt(guruId) : null
                });
                api.toast('Kelas baru berhasil ditambahkan!', 'success');
            }
            closeModal();
            await loadData();
        } catch (e) {
            api.toast(e.message || 'Gagal menyimpan kelas', 'error');
        } finally {
            btn.disabled = false;
            btn.innerHTML = '<span class="material-symbols-outlined text-base">save</span> Simpan';
        }
    }

    function openHapusModal(id, nama, siswaCount) {
        if (siswaCount > 0) {
            api.toast(`Kelas tidak bisa dinonaktifkan karena masih ada ${siswaCount} siswa. Pindahkan siswa terlebih dahulu.`, 'error');
            return;
        }
        hapusId = id;
        document.getElementById('hapus-nama').textContent = nama;
        document.getElementById('hapus-modal').classList.remove('hidden');
        document.getElementById('hapus-modal').classList.add('flex');
    }

    function closeHapusModal() {
        document.getElementById('hapus-modal').classList.add('hidden');
        document.getElementById('hapus-modal').classList.remove('flex');
        hapusId = null;
    }

    async function konfirmasiHapus() {
        if (!hapusId) return;
        const btn = document.getElementById('btn-konfirmasi-hapus');
        btn.disabled = true;
        btn.textContent = 'Memproses...';
        try {
            await api.delete(`/api/admin/hapus-kelas.php?id=${hapusId}`);
            api.toast('Kelas berhasil dinonaktifkan', 'success');
            closeHapusModal();
            await loadData();
        } catch (e) {
            api.toast(e.message || 'Gagal menonaktifkan kelas', 'error');
            btn.disabled = false;
            btn.textContent = 'Nonaktifkan';
        }
    }
    </script>
</body>
</html>
