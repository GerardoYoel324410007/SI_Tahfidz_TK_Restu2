<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My Google AI Studio App</title>
    <script type="module" crossorigin src="/assets/index-CV3qkEWC.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-Cwh9gO0y.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>

