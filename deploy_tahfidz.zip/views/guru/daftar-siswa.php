<?php require_once __DIR__ . '/../../config/view_auth.php'; requireAnyRole(['guru', 'karyawan']); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Daftar Siswa - Tahfidz BA Restu Z</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: { extend: {
                "colors": { "tertiary": "#003580","primary-fixed": "#a9f3be","on-primary": "#ffffff","primary": "#004323","error": "#ba1a1a","on-surface": "#191c1c","surface-bright": "#f8faf9","surface-container-lowest": "#ffffff","surface-container": "#eceeed","outline-variant": "#bfc9bf","on-surface-variant": "#404941","secondary": "#964900","secondary-container": "#fe8a29" },
                "borderRadius": {"DEFAULT": "1rem","lg": "1.5rem","full": "9999px"},
                "fontFamily": {"label-md": ["Plus Jakarta Sans"],"headline-sm": ["Plus Jakarta Sans"],"body-md": ["Plus Jakarta Sans"],"headline-md": ["Plus Jakarta Sans"]},
                "fontSize": { "label-md": ["14px",{"lineHeight":"20px","fontWeight":"600"}],"headline-sm": ["20px",{"lineHeight":"28px","fontWeight":"600"}],"body-md": ["16px",{"lineHeight":"24px","fontWeight":"400"}],"headline-md": ["24px",{"lineHeight":"32px","fontWeight":"700"}] }
            }}
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
    </style>
    <script src="../../assets/js/api.js?v=5"></script>
    <script src="../../assets/js/auth-guard.js?v=5"></script>
</head>
<body class="bg-surface-bright text-on-surface min-h-screen antialiased">
    <aside id="sidebar" class="fixed left-0 top-0 h-full w-72 bg-primary shadow-[40px_0_60px_-15px_rgba(0,67,35,0.15)] flex-col py-8 z-50 transform transition-transform duration-300 -translate-x-full md:translate-x-0 hidden md:flex overflow-y-auto"></aside>

    <main class="ml-0 md:ml-72 min-h-screen w-full md:w-[calc(100%-18rem)] pb-32">
        <header class="h-20 sticky top-0 z-40 bg-surface-bright/80 backdrop-blur-md shadow-sm flex justify-between items-center px-4 md:px-margin-desktop">
            <div class="flex items-center gap-3">
                <button id="mobile-menu-btn" class="md:hidden p-2 hover:bg-surface-container-high rounded-full transition-all text-on-surface-variant flex-shrink-0">
                    <span class="material-symbols-outlined">menu</span>
                </button>
                <!-- Desktop Collapse Button -->
                <button id="desktop-collapse-btn" class="hidden md:flex p-2 hover:bg-surface-container-high rounded-full transition-all text-on-surface-variant mr-2" title="Lipat Menu">
                    <span class="material-symbols-outlined">menu_open</span>
                </button>
                <h2 class="font-headline-sm text-headline-sm font-bold">Daftar Siswa</h2>
            </div>
            <div class="flex items-center gap-2 md:gap-4">
                <div class="flex items-center gap-2 md:gap-3">
                    <div class="text-right hidden sm:block">
                        <p class="font-label-md text-label-md text-on-surface" id="header-nama">-</p>
                        <p class="text-[12px] text-on-surface-variant">Wali Kelas</p>
                    </div>
                    <div class="w-10 h-10 rounded-full bg-primary-fixed flex items-center justify-center text-primary font-bold text-sm border-2 border-primary-fixed" id="header-initials">-</div>
                </div>
                <button onclick="authGuard.logout()" class="bg-error text-on-error px-4 py-2 rounded-full text-xs md:text-sm font-bold active:opacity-80 transition-all ml-1 md:ml-2">Logout</button>
            </div>
        </header>

        <div class="p-4 md:p-12">
            <!-- Search Input Container -->
            <div class="mb-6 flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4">
                <div class="relative flex items-center bg-white border border-outline-variant rounded-full px-4 py-2.5 shadow-sm max-w-md w-full">
                    <span class="material-symbols-outlined text-on-surface-variant mr-2">search</span>
                    <input id="search-input" class="bg-transparent border-none focus:ring-0 text-body-md w-full outline-none" placeholder="Cari nama atau NIS siswa..." type="text">
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-sm overflow-hidden">
                <div class="p-4 md:p-8">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-separate border-spacing-0">
                            <thead>
                                <tr class="bg-surface-container-low">
                                    <th class="px-6 py-4 rounded-tl-lg font-label-md text-on-surface-variant border-b border-outline-variant hidden sm:table-cell">NIS</th>
                                    <th class="px-6 py-4 rounded-tl-lg sm:rounded-none font-label-md text-on-surface-variant border-b border-outline-variant">Nama Lengkap</th>
                                    <th class="px-6 py-4 font-label-md text-on-surface-variant border-b border-outline-variant hidden md:table-cell">Nama Panggilan</th>
                                    <th class="px-6 py-4 rounded-tr-lg sm:rounded-none font-label-md text-on-surface-variant border-b border-outline-variant">JK</th>
                                    <th class="px-6 py-4 rounded-tr-lg font-label-md text-on-surface-variant border-b border-outline-variant hidden sm:table-cell">Kelas</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-outline-variant/30" id="siswa-body">
                                <tr><td colspan="5" class="px-6 py-8 text-center text-on-surface-variant">Memuat data...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
 
    <script>
    let currentKelasId = null;
    document.addEventListener('DOMContentLoaded', async () => {
        const user = await authGuard.protect('guru');
        if (!user) return;
        authGuard.initUserData(user);

        // Load stats to get teacher's class
        try {
            const statsRes = await api.get('/api/guru/beranda-stats.php');
            if (statsRes.data && statsRes.data.guru) {
                const g = statsRes.data.guru;
                currentKelasId = g.kelas_id;
                document.getElementById('header-nama').textContent = g.nama;
                const initials = g.nama.split(' ').map(w => w[0]).join('').substring(0,2).toUpperCase();
                document.getElementById('header-initials').textContent = initials;
                document.querySelector('h2.font-headline-sm').textContent = `Daftar Siswa — ${g.kelas}`;
            }
        } catch (err) {
            console.error('Gagal memuat profil kelas:', err);
        }

        async function loadSiswa(search = '') {
            try {
                let url = `/api/admin/daftar-siswa.php?kelas_id=${currentKelasId || ''}`;
                if (search) {
                    url += `&search=${encodeURIComponent(search)}`;
                }
                const res = await api.get(url);
                const tbody = document.getElementById('siswa-body');
                const list = (res.data && res.data.data) ? res.data.data : [];
                if (list.length > 0) {
                    tbody.innerHTML = list.map(s => {
                        const initials = s.nama_lengkap.split(' ').map(w => w[0]).join('').substring(0,2).toUpperCase();
                        return `
                        <tr class="hover:bg-surface-bright transition-colors">
                            <td class="px-6 py-4 font-body-md text-on-surface-variant hidden sm:table-cell">${s.nis}</td>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary text-sm">${initials}</div>
                                    <div>
                                        <span class="font-body-md text-on-surface font-semibold block">${s.nama_lengkap}</span>
                                        <span class="text-[12px] text-on-surface-variant block sm:hidden">NIS: ${s.nis}</span>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 font-body-md text-on-surface-variant hidden md:table-cell">${s.nama_panggilan || '-'}</td>
                            <td class="px-6 py-4">
                                <span class="px-3 py-1 bg-primary/10 text-primary rounded-full text-label-md hidden sm:inline-block">${s.jenis_kelamin === 'L' ? 'Laki-laki' : 'Perempuan'}</span>
                                <span class="px-2.5 py-0.5 bg-primary/10 text-primary rounded-full text-xs font-bold sm:hidden">${s.jenis_kelamin}</span>
                            </td>
                            <td class="px-6 py-4 hidden sm:table-cell"><span class="px-3 py-1 bg-tertiary/10 text-tertiary rounded-full text-label-md">${s.nama_kelas}</span></td>
                        </tr>`;
                    }).join('');
                } else {
                    tbody.innerHTML = '<tr><td colspan="5" class="px-6 py-8 text-center text-on-surface-variant">Tidak ada data siswa</td></tr>';
                }
            } catch (err) {
                console.error(err);
            }
        }

        await loadSiswa();

        let timeout;
        document.getElementById('search-input').addEventListener('input', (e) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => loadSiswa(e.target.value), 300);
        });
    });
    </script>
</body>
</html>
