# Panduan Instalasi — Sistem Informasi Tahfidz Restu 2

Panduan singkat untuk menjalankan aplikasi di laptop baru menggunakan **Laragon**.

## Kebutuhan Awal
1. **Laragon** (PHP 8.0+ dan MySQL/MariaDB).
2. **Koneksi internet** saat membuka aplikasi (tampilan menggunakan Tailwind CSS & Google Fonts dari CDN).
3. **Browser modern** (Chrome / Edge / Firefox) di laptop yang sama.

## Langkah Instalasi

1. **Jalankan Laragon**, lalu klik **Start All** (pastikan Apache dan MySQL aktif).
2. **Ekstrak file ZIP** ke folder web server Laragon, misalnya:
   `C:\laragon\www\deploy_tahfidz`
   > Jika sebelumnya sudah pernah mengekstrak ZIP versi lama, hapus folder lama terlebih dahulu lalu ekstrak ulang.
3. **Impor Database** dengan membuka alamat berikut di browser:
   `http://localhost/deploy_tahfidz/setup.php`
   > Jika nama folder Anda berbeda, sesuaikan `deploy_tahfidz` dengan nama folder tersebut.
   > Database `tahfidz_restu2` akan dibuat dan diisi otomatis (jika sudah ada, tabel akan diperbarui otomatis).
4. **Cek Kesiapan Sistem** dengan membuka:
   `http://localhost/deploy_tahfidz/cek_sistem.php`
   Pastikan seluruh komponen wajib berstatus **OK**.
5. **Buka Aplikasi**:
   `http://localhost/deploy_tahfidz/`

## Akun Login Default (Admin)
- **Nomor Identitas:** `000001`
- **Password:** `admin123`

*(Untuk akun guru dan wali murid, gunakan daftar akun uji yang diberikan oleh pengirim.)*

## Catatan Penting Saat Pengujian
- **Selalu akses melalui `http://localhost/...`** di laptop yang sama. Fitur **rekam audio** (panduan guru dan setoran wali murid) diblokir oleh browser jika dibuka melalui alamat IP (misalnya `192.168.x.x`) tanpa HTTPS.
- Jika fitur **Import/Export Excel** gagal, buka `cek_sistem.php` dan pastikan ekstensi PHP `zip` dan `gd` berstatus **OK**.
- Jika koneksi database gagal (misal MySQL Anda memakai password selain kosong), sesuaikan `$username`, `$password`, atau `$host` pada file `config/database.php` dan `setup.php`.
