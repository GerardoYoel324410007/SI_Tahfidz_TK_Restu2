<?php require_once __DIR__ . '/../../config/view_auth.php'; requireRole('wali_murid'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Beranda - Tahfidz Parent Portal</title>
    <meta name="description" content="Beranda wali murid untuk memantau status tugas, progres hafalan, dan catatan ustadz anak.">
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    "colors": {
                        "on-surface": "#191c1c","background": "#f8faf9","on-primary-fixed": "#00210e",
                        "on-primary-container": "#8ad2a0","surface-bright": "#f8faf9","surface": "#f8faf9",
                        "surface-variant": "#e1e3e2","secondary-container": "#fe8a29","surface-container-lowest": "#ffffff",
                        "on-primary": "#ffffff","primary": "#004323","on-tertiary-container": "#aac1ff",
                        "on-error": "#ffffff","on-secondary": "#ffffff","outline-variant": "#bfc9bf",
                        "secondary": "#964900","primary-fixed": "#a9f3be","on-tertiary": "#ffffff",
                        "on-primary-fixed-variant": "#00522c","error-container": "#ffdad6","tertiary": "#003580",
                        "tertiary-fixed": "#d9e2ff","on-secondary-fixed": "#311300","primary-fixed-dim": "#8dd6a3",
                        "on-secondary-container": "#642f00","outline": "#707a70","on-surface-variant": "#404941",
                        "on-background": "#191c1c","inverse-primary": "#8dd6a3","inverse-surface": "#2e3131",
                        "surface-container-highest": "#e1e3e2","surface-container-low": "#f2f4f3",
                        "surface-container": "#eceeed","surface-container-high": "#e6e9e8",
                        "on-error-container": "#93000a","primary-container": "#0d5c34","tertiary-fixed-dim": "#b0c6ff",
                        "on-tertiary-fixed-variant": "#00429c","tertiary-container": "#004aae",
                        "surface-tint": "#226b41","surface-dim": "#d8dada","secondary-fixed-dim": "#ffb786",
                        "on-tertiary-fixed": "#001945","inverse-on-surface": "#eff1f0",
                        "secondary-fixed": "#ffdcc6","on-secondary-fixed-variant": "#723600","error": "#ba1a1a"
                    },
                    "borderRadius": {"DEFAULT": "1rem","lg": "2rem","xl": "3rem","full": "9999px"},
                    "spacing": {"container-padding-sm": "16px","margin-mobile": "16px","base": "8px","margin-desktop": "48px","container-padding-md": "24px","gutter": "20px"},
                    "fontFamily": {"headline-lg-mobile": ["Plus Jakarta Sans"],"headline-lg": ["Plus Jakarta Sans"],"body-md": ["Plus Jakarta Sans"],"label-md": ["Plus Jakarta Sans"],"headline-md": ["Plus Jakarta Sans"],"headline-sm": ["Plus Jakarta Sans"],"body-lg": ["Plus Jakarta Sans"]},
                    "fontSize": {
                        "headline-lg-mobile": ["26px", {"lineHeight": "34px","fontWeight": "700"}],
                        "headline-lg": ["32px", {"lineHeight": "40px","letterSpacing": "-0.02em","fontWeight": "700"}],
                        "body-md": ["16px", {"lineHeight": "24px","fontWeight": "400"}],
                        "label-md": ["14px", {"lineHeight": "20px","fontWeight": "600"}],
                        "headline-md": ["24px", {"lineHeight": "32px","letterSpacing": "-0.01em","fontWeight": "700"}],
                        "headline-sm": ["20px", {"lineHeight": "28px","fontWeight": "600"}],
                        "body-lg": ["18px", {"lineHeight": "26px","fontWeight": "500"}]
                    }
                },
            },
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; min-height: max(884px, 100dvh); background-color: #f8faf9; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24; }
    </style>
    <script src="../../assets/js/api.js?v=5"></script>
    <script src="../../assets/js/auth-guard.js?v=5"></script>
</head>
<body class="bg-background text-on-background font-body-md antialiased">
    <!-- Top App Bar -->
    <header class="bg-primary shadow-[0px_20px_40px_rgba(0,67,35,0.15)] rounded-b-lg sticky top-0 z-50 w-full flex justify-between items-center px-margin-mobile py-3">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-full border-2 border-on-primary-container overflow-hidden bg-white flex items-center justify-center">
                <img alt="Logo Restu Z" class="w-full h-full object-contain p-0.5" src="../../LOGO Restu 2 Excellent.png">
            </div>
            <div>
                <p class="font-headline-sm text-headline-sm-mobile text-on-primary font-bold leading-tight" id="header-nama">-</p>
                <p class="font-label-md text-label-md text-on-primary/80" id="header-kelas">-</p>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <button onclick="authGuard.logout()" class="bg-[#ba1a1a] text-white px-4 py-1.5 rounded-full font-bold text-xs active:scale-95 transition-all flex items-center gap-1.5 shadow-md hover:bg-[#ba1a1a]/90" title="Logout">
                <span class="material-symbols-outlined text-sm">logout</span>
                <span>Keluar</span>
            </button>
        </div>
    </header>

    <main class="px-margin-mobile pt-6 pb-24 space-y-6 max-w-2xl mx-auto">
        <!-- Status Tugas Hari Ini -->
        <section class="space-y-4">
            <h2 class="font-headline-md text-headline-md text-on-surface">Status Tugas Hari Ini</h2>
            <div id="status-container">
                <!-- Dimuat dari API -->
                <div class="bg-gray-50 p-5 rounded-lg text-center text-on-surface-variant">Memuat...</div>
            </div>
        </section>

        <!-- Bento Stats -->
        <section class="grid grid-cols-2 gap-4">
            <div class="col-span-2 bg-surface-container-lowest p-6 rounded-lg shadow-[0px_20px_40px_rgba(0,0,0,0.05)] border border-outline-variant/10 relative overflow-hidden h-40">
                <div class="relative z-10 h-full flex flex-col justify-between">
                    <div>
                        <p class="font-label-md text-label-md text-tertiary">Progress Hafalan</p>
                        <p class="font-headline-lg text-headline-lg-mobile text-on-surface" id="stat-progress-label">-</p>
                    </div>
                    <div class="w-full bg-surface-container-high rounded-full h-2">
                        <div class="bg-tertiary h-2 rounded-full transition-all duration-700" id="stat-progress-bar" style="width: 0%"></div>
                    </div>
                </div>
                <div class="absolute -right-4 -bottom-4 opacity-10">
                    <span class="material-symbols-outlined text-[120px]">auto_stories</span>
                </div>
            </div>
            <div class="bg-surface-container-lowest p-6 rounded-lg shadow-[0px_20px_40px_rgba(0,0,0,0.05)] border border-outline-variant/10">
                <span class="material-symbols-outlined text-primary mb-2">stars</span>
                <p class="font-label-md text-label-md text-on-surface-variant">Poin Anak</p>
                <p class="font-headline-md text-headline-md text-primary" id="stat-poin">-</p>
            </div>
            <div class="bg-surface-container-lowest p-6 rounded-lg shadow-[0px_20px_40px_rgba(0,0,0,0.05)] border border-outline-variant/10">
                <span class="material-symbols-outlined text-secondary mb-2">history_edu</span>
                <p class="font-label-md text-label-md text-on-surface-variant">Presensi</p>
                <p class="font-headline-md text-headline-md text-secondary" id="stat-presensi">-</p>
            </div>
        </section>

        <!-- Catatan Ustadz -->
        <section class="space-y-4">
            <h2 class="font-headline-md text-headline-md text-on-surface">Catatan Ustadz</h2>
            <div id="catatan-container">
                <div class="bg-surface-container-lowest p-5 rounded-lg text-center text-on-surface-variant">Memuat...</div>
        <!-- Section Ganti Password -->
        <div id="ganti-password-section"></div>
    </main>

    <!-- Bottom Navigation -->
    <nav class="fixed bottom-0 left-0 w-full z-50 flex justify-around items-center px-2 pb-4 pt-2 bg-surface shadow-[0px_-4px_20px_rgba(0,0,0,0.05)] rounded-t-lg">
        <a class="flex flex-col items-center justify-center bg-secondary-container text-on-secondary-container rounded-2xl px-5 py-2 active:scale-90 transition-all duration-200" href="beranda.php">
            <span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">home</span>
            <span class="font-label-md text-xs mt-1">Home</span>
        </a>
        <a class="flex flex-col items-center justify-center text-on-surface-variant hover:bg-surface-container-high px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200 relative" href="setoran.php">
            <span class="material-symbols-outlined">cloud_upload</span>
            <span class="font-label-md text-xs mt-1">Setor</span>
            <span id="setor-notif-dot" class="absolute top-2 right-6 w-2.5 h-2.5 bg-red-600 rounded-full hidden"></span>
        </a>
        <a class="flex flex-col items-center justify-center text-on-surface-variant hover:bg-surface-container-high px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200" href="histori.php">
            <span class="material-symbols-outlined">history</span>
            <span class="font-label-md text-xs mt-1">Histori</span>
        </a>
        <a class="flex flex-col items-center justify-center text-on-surface-variant hover:bg-surface-container-high px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200" href="raport.php">
            <span class="material-symbols-outlined">insights</span>
            <span class="font-label-md text-xs mt-1">Progress</span>
        </a>
        <button onclick="authGuard.logout()" class="flex flex-col items-center justify-center text-[#ba1a1a] hover:bg-red-50 px-5 py-2 rounded-2xl active:scale-90 transition-all duration-200">
            <span class="material-symbols-outlined">logout</span>
            <span class="font-label-md text-xs mt-1">Keluar</span>
        </button>
    </nav>

    <!-- Modal Popup Pengingat Deadline (Premium Design) -->
    <div id="deadline-modal" class="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm hidden opacity-0 transition-opacity duration-300">
        <div class="bg-white rounded-[24px] max-w-md w-full p-8 shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-amber-200/50 transform scale-95 transition-transform duration-300 relative overflow-hidden">
            <!-- Premium Amber/Gold Highlight ring decoration -->
            <div class="absolute -right-16 -top-16 w-32 h-32 bg-amber-500/10 rounded-full blur-xl"></div>
            <div class="absolute -left-16 -bottom-16 w-32 h-32 bg-primary/10 rounded-full blur-xl"></div>
            
            <div class="flex flex-col items-center text-center space-y-6">
                <!-- Icon Header -->
                <div class="w-20 h-20 rounded-full bg-amber-50 flex items-center justify-center shadow-[0_8px_16px_rgba(251,192,45,0.2)]">
                    <span class="material-symbols-outlined text-[44px] text-[#FBC02D] animate-bounce">alarm</span>
                </div>
                
                <div class="space-y-2">
                    <h3 class="font-headline-md text-headline-md text-on-surface font-extrabold">Pengingat Setoran!</h3>
                    <p class="font-body-md text-on-surface-variant text-sm px-2">Anda memiliki tugas hafalan aktif hari ini yang belum disetorkan.</p>
                </div>
                
                <!-- Task Details Card -->
                <div class="w-full bg-amber-50/50 border border-amber-200/60 rounded-2xl p-5 space-y-3">
                    <div>
                        <p class="text-[11px] font-bold text-amber-800 uppercase tracking-widest">Tugas Hari Ini</p>
                        <p id="modal-task-title" class="font-headline-sm text-headline-sm-mobile text-[#964900] font-bold mt-1">-</p>
                    </div>
                    <div class="h-px bg-amber-200/40 w-full"></div>
                    <div>
                        <p class="text-[11px] font-bold text-amber-800 uppercase tracking-widest">Batas Pengumpulan</p>
                        <p id="modal-task-deadline" class="font-label-md text-on-surface font-semibold mt-1">-</p>
                    </div>
                </div>
                
                <!-- Action Buttons -->
                <div class="flex flex-col w-full gap-3">
                    <a href="setoran.php" class="w-full bg-[#FE8A29] hover:bg-orange-600 text-white font-bold py-4 rounded-full shadow-[0_10px_20px_-5px_rgba(254,138,41,0.4)] active:scale-98 transition-all flex items-center justify-center gap-2 text-center">
                        <span class="material-symbols-outlined text-sm">cloud_upload</span>
                        <span>Kirim Setoran Sekarang</span>
                    </a>
                    <button onclick="closeDeadlineModal()" class="w-full bg-surface-container-high text-on-surface-variant font-label-md py-3.5 rounded-full hover:bg-surface-dim active:scale-98 transition-all">
                        Nanti Saja
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
    function formatDeadline(deadlineStr) {
        if (!deadlineStr) return '';
        try {
            const dlString = deadlineStr.replace(/-/g, "/");
            const deadlineDate = new Date(dlString);
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
            return deadlineDate.toLocaleDateString('id-ID', options) + ' WIB';
        } catch (e) {
            console.error('Error formatting deadline:', e);
            return deadlineStr;
        }
    }

    function openDeadlineModal(tugasText, deadlineText) {
        const modal = document.getElementById('deadline-modal');
        document.getElementById('modal-task-title').textContent = tugasText;
        document.getElementById('modal-task-deadline').textContent = deadlineText;
        
        modal.classList.remove('hidden');
        setTimeout(() => {
            modal.classList.remove('opacity-0');
            modal.classList.add('opacity-100');
            modal.querySelector('.bg-white').classList.remove('scale-95');
            modal.querySelector('.bg-white').classList.add('scale-100');
        }, 50);
    }

    function closeDeadlineModal() {
        const modal = document.getElementById('deadline-modal');
        modal.classList.remove('opacity-100');
        modal.classList.add('opacity-0');
        modal.querySelector('.bg-white').classList.remove('scale-100');
        modal.querySelector('.bg-white').classList.add('scale-95');
        setTimeout(() => {
            modal.classList.add('hidden');
        }, 300);
    }

    document.addEventListener('DOMContentLoaded', async () => {
        const user = await authGuard.protect('wali_murid');
        if (!user) return;
        try {
            const res = await api.get('/api/wali/beranda.php');
            const d = res.data;

            // Header
            document.getElementById('header-nama').textContent = d.siswa.nama;
            document.getElementById('header-kelas').textContent = d.siswa.kelas;
            document.getElementById('stat-poin').textContent = d.siswa.poin ?? '0';
            document.getElementById('stat-presensi').textContent = d.siswa.presensi ?? '0%';

            // Load Raport for Progress Hafalan
            try {
                const raportRes = await api.get(`/api/wali/raport.php?bulan=${new Date().getMonth() + 1}&tahun=${new Date().getFullYear()}`);
                const r = raportRes.data.ringkasan;
                const pct = r.persentase_berhasil || 0;
                document.getElementById('stat-progress-label').textContent = `${pct}% Tuntas`;
                document.getElementById('stat-progress-bar').style.width = `${pct}%`;
            } catch (err) {
                console.error('Gagal memuat progres hafalan:', err);
                document.getElementById('stat-progress-label').textContent = '0% Tuntas';
            }

            // Status tugas
            const sc = document.getElementById('status-container');
            const status = d.setoran_hari_ini.status;
            const tugas = d.tugas;
            const babText = tugas && tugas.bab ? ` (${tugas.bab})` : '';
            const tugasText = tugas ? `${tugas.nama_surat}${babText} Ayat ${tugas.ayat_dari}-${tugas.ayat_sampai}` : '-';

            if (tugas && status === 'belum_kumpul' && !d.setoran_hari_ini.is_locked) {
                const dot = document.getElementById('setor-notif-dot');
                if (dot) dot.classList.remove('hidden');

                // Trigger modal popup once per session
                if (!sessionStorage.getItem('deadline_modal_shown')) {
                    const dlText = tugas.deadline ? formatDeadline(tugas.deadline) : 'Hari ini';
                    openDeadlineModal(`QS. ${tugasText}`, dlText);
                    sessionStorage.setItem('deadline_modal_shown', 'true');
                }
            }

            if (status === 'belum_kumpul') {
                const locked = d.setoran_hari_ini.is_locked;
                const deadlineFormatted = tugas && tugas.deadline ? formatDeadline(tugas.deadline) : '';
                sc.innerHTML = `
                    <div class="bg-[#FFF9C4] border-l-8 border-[#FBC02D] p-5 rounded-lg shadow-sm flex items-start gap-4">
                        <div class="bg-[#FBC02D] p-2 rounded-full flex-shrink-0">
                            <span class="material-symbols-outlined text-white" style="font-variation-settings: 'FILL' 1;">warning</span>
                        </div>
                        <div class="flex-1">
                            <p class="font-headline-sm text-headline-sm-mobile text-on-surface-variant font-bold">Belum Mengumpul</p>
                            <p class="font-body-md text-body-md text-on-surface-variant mt-1">${tugas ? 'Tugas: ' + tugasText + ' belum disetorkan hari ini.' : 'Tidak ada tugas hari ini.'}</p>
                            ${deadlineFormatted ? `<p class="text-[12px] font-bold text-amber-800 uppercase tracking-wider mt-2 flex items-center gap-1"><span class="material-symbols-outlined text-sm font-bold">alarm</span> Batas Waktu: ${deadlineFormatted}</p>` : ''}
                            ${locked ? '<p class="text-error text-sm mt-2 font-bold">Batas waktu sudah habis. Hubungi wali kelas.</p>' : `
                            <a href="setoran.php" class="mt-4 bg-secondary-container text-on-secondary-container font-label-md text-label-md px-6 py-3 rounded-full shadow-md active:scale-95 transition-all inline-block text-center">
                                Kirim Sekarang
                            </a>`}
                        </div>
                    </div>`;
            } else if (status === 'menunggu') {
                sc.innerHTML = `
                    <div class="bg-[#E3F2FD] border-l-8 border-[#1976D2] p-5 rounded-lg shadow-sm flex items-start gap-4">
                        <div class="bg-[#1976D2] p-2 rounded-full flex-shrink-0">
                            <span class="material-symbols-outlined text-white" style="font-variation-settings: 'FILL' 1;">hourglass_empty</span>
                        </div>
                        <div class="flex-1">
                            <p class="font-headline-sm text-headline-sm-mobile text-[#1565C0] font-bold">Menunggu Koreksi</p>
                            <p class="font-body-md text-body-md text-on-surface-variant mt-1">Setoran ${tugasText} sudah dikirim. Menunggu guru mengoreksi.</p>
                        </div>
                    </div>`;
            } else if (status === 'diterima') {
                sc.innerHTML = `
                    <div class="bg-[#E8F5E9] border-l-8 border-[#4CAF50] p-5 rounded-lg shadow-sm flex items-start gap-4">
                        <div class="bg-[#4CAF50] p-2 rounded-full flex-shrink-0">
                            <span class="material-symbols-outlined text-white" style="font-variation-settings: 'FILL' 1;">check_circle</span>
                        </div>
                        <div class="flex-1">
                            <p class="font-headline-sm text-headline-sm-mobile text-[#2E7D32] font-bold">Alhamdulillah, Diterima!</p>
                            <p class="font-body-md text-body-md text-on-surface-variant mt-1">Setoran ${tugasText} telah diterima guru.</p>
                            <a href="koreksi-detail.php?setoran_id=${d.setoran_hari_ini.setoran.id}" class="text-tertiary font-label-md text-label-md hover:underline mt-2 inline-block">Lihat Detail</a>
                        </div>
                    </div>`;
            } else if (status === 'perbaiki') {
                sc.innerHTML = `
                    <div class="bg-[#FFEBEE] border-l-8 border-[#EF5350] p-5 rounded-lg shadow-sm flex items-start gap-4">
                        <div class="bg-[#EF5350] p-2 rounded-full flex-shrink-0">
                            <span class="material-symbols-outlined text-white" style="font-variation-settings: 'FILL' 1;">error</span>
                        </div>
                        <div class="flex-1">
                            <p class="font-headline-sm text-headline-sm-mobile text-[#C62828] font-bold">Perlu Perbaikan</p>
                            <p class="font-body-md text-body-md text-on-surface-variant mt-1">Setoran ${tugasText} perlu diperbaiki.</p>
                            <a href="koreksi-detail.php?setoran_id=${d.setoran_hari_ini.setoran.id}" class="text-tertiary font-label-md text-label-md hover:underline mt-2 inline-block">Lihat Catatan Guru</a>
                            <a href="setoran.php" class="mt-2 bg-secondary-container text-on-secondary-container font-label-md text-label-md px-6 py-3 rounded-full shadow-md active:scale-95 transition-all inline-block text-center">Kirim Ulang</a>
                        </div>
                    </div>`;
            }

            // Catatan terbaru
            const cc = document.getElementById('catatan-container');
            if (d.setoran_hari_ini.setoran && d.setoran_hari_ini.setoran.catatan_guru) {
                const s = d.setoran_hari_ini.setoran;
                cc.innerHTML = `
                    <div class="bg-surface-container-lowest p-5 rounded-lg shadow-[0px_20px_40px_rgba(0,0,0,0.05)] border border-outline-variant/10 space-y-4">
                        <p class="font-body-md text-body-md text-on-surface-variant">${s.catatan_guru}</p>
                        <a href="koreksi-detail.php?setoran_id=${s.id}" class="flex items-center gap-1 text-tertiary font-label-md text-label-md hover:underline">
                            Lihat Detail Koreksi <span class="material-symbols-outlined text-sm">arrow_forward</span>
                        </a>
                    </div>`;
            } else {
                cc.innerHTML = '<div class="bg-surface-container-lowest p-5 rounded-lg text-center text-on-surface-variant">Belum ada catatan dari guru hari ini.</div>';
            }
        } catch (err) {
            console.error('Gagal memuat beranda:', err);
        }

        // ── Ganti Password ──────────────────────────────────────────────
        await loadStatusPermintaanPassword();
    });

    async function loadStatusPermintaanPassword() {
        try {
            const res = await api.get('/api/auth/status-permintaan-password.php');
            renderStatusPassword(res.data?.permintaan);
        } catch(e) { console.error('Gagal cek status password', e); }
    }

    function renderStatusPassword(p) {
        const sec = document.getElementById('ganti-password-section');
        if (!sec) return;

        if (!p || p.status === 'disetujui' || p.status === 'ditolak') {
            const alasanHtml = (p && p.status === 'ditolak' && p.alasan_tolak)
                ? `<div class="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">
                     <strong>Permintaan ditolak:</strong> ${p.alasan_tolak}
                   </div>` : '';
            const berhasilHtml = (p && p.status === 'disetujui')
                ? `<div class="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-sm text-green-700">
                     <strong>Password berhasil diubah!</strong> Anda dapat mengajukan perubahan baru jika perlu.
                   </div>` : '';

            sec.innerHTML = `
                <section class="space-y-4">
                    <div class="bg-white rounded-xl shadow-[0px_4px_20px_rgba(0,0,0,0.06)] p-5">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-10 h-10 bg-tertiary/10 rounded-full flex items-center justify-center">
                                <span class="material-symbols-outlined text-tertiary" style="font-variation-settings:'FILL' 0;">lock_reset</span>
                            </div>
                            <div>
                                <p class="font-semibold text-on-surface text-sm">Ganti Password</p>
                                <p class="text-xs text-on-surface-variant">Permintaan ditinjau Admin sebelum berlaku</p>
                            </div>
                        </div>
                        ${berhasilHtml}${alasanHtml}
                        <div class="space-y-3">
                            <div>
                                <label class="block text-sm font-medium text-on-surface mb-1">Password Baru <span class="text-error">*</span></label>
                                <input type="password" id="pp-baru" placeholder="Minimal 8 karakter" class="w-full border border-outline-variant rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-tertiary/30 focus:border-tertiary">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-on-surface mb-1">Konfirmasi Password <span class="text-error">*</span></label>
                                <input type="password" id="pp-konfirmasi" placeholder="Ulangi password baru" class="w-full border border-outline-variant rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-tertiary/30 focus:border-tertiary">
                            </div>
                            <p class="text-xs text-on-surface-variant">Password baru aktif setelah disetujui Admin.</p>
                            <button onclick="ajukanGantiPassword()" id="btn-ajukan-pp" class="w-full py-3 bg-primary text-white rounded-xl font-bold text-sm active:scale-95 transition-all flex items-center justify-center gap-2 shadow-md">
                                <span class="material-symbols-outlined text-sm">send</span> Kirim Permintaan
                            </button>
                        </div>
                    </div>
                </section>`;
        } else if (p.status === 'menunggu') {
            const waktu = new Date(p.created_at.replace(' ', 'T'));
            const waktuStr = waktu.toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
            sec.innerHTML = `
                <section>
                    <div class="bg-amber-50 border border-amber-200 rounded-xl p-5 flex items-start gap-4">
                        <span class="material-symbols-outlined text-amber-500 text-2xl mt-0.5" style="font-variation-settings:'FILL' 1;">hourglass_empty</span>
                        <div>
                            <p class="font-semibold text-amber-800 text-sm">Permintaan Password Menunggu</p>
                            <p class="text-xs text-amber-700 mt-1">Menunggu persetujuan Admin. Diajukan: ${waktuStr}</p>
                        </div>
                    </div>
                </section>`;
        }
    }

    async function ajukanGantiPassword() {
        const baru       = document.getElementById('pp-baru').value;
        const konfirmasi = document.getElementById('pp-konfirmasi').value;
        const btn        = document.getElementById('btn-ajukan-pp');
        if (!baru || !konfirmasi) { alert('Semua field wajib diisi.'); return; }
        if (baru.length < 8)     { alert('Password minimal 8 karakter.'); return; }
        if (baru !== konfirmasi) { alert('Konfirmasi password tidak cocok.'); return; }
        btn.disabled = true; btn.textContent = 'Mengirim...';
        try {
            await api.post('/api/auth/ajukan-ganti-password.php', { password_baru: baru, konfirmasi });
            await loadStatusPermintaanPassword();
        } catch(e) {
            alert('Gagal: ' + (e.message || 'Kesalahan tidak diketahui'));
            btn.disabled = false;
            btn.innerHTML = '<span class="material-symbols-outlined text-sm">send</span> Kirim Permintaan';
        }
    }
    </script>

</body>
</html>

