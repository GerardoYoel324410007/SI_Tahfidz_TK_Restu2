<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tahfidz BA Portal - UML Diagram Viewer</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#004323',
                        accent: '#008542',
                        dark: '#121212',
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f3f4f6;
        }
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
        /* Grid pattern background for canvas */
        .canvas-bg {
            background-color: #ffffff;
            background-image: radial-gradient(#e5e7eb 1.5px, transparent 1.5px);
            background-size: 24px 24px;
        }
    </style>
</head>
<body class="h-screen flex flex-col overflow-hidden">

    <!-- Top Header Navigation -->
    <header class="bg-primary text-white px-6 py-4 flex flex-wrap justify-between items-center shadow-lg z-10">
        <div class="flex items-center space-x-3">
            <div class="bg-white p-1.5 rounded-lg">
                <svg class="w-8 h-8 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path>
                </svg>
            </div>
            <div>
                <h1 class="text-xl font-bold tracking-tight">Tahfidz BA Portal</h1>
                <p class="text-xs text-green-300">UML Diagram Viewer &bull; Versi 100% Selaras Database</p>
            </div>
        </div>
        <div class="flex items-center space-x-2 mt-2 sm:mt-0">
            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                <span class="w-1.5 h-1.5 mr-1.5 bg-green-500 rounded-full animate-ping"></span>
                Aktif & Sesuai Database
            </span>
            <a href="../index.php" class="text-xs bg-accent hover:bg-green-700 transition px-3 py-1.5 rounded text-white font-medium flex items-center">
                <svg class="w-3.5 h-3.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path>
                </svg>
                Kembali ke Aplikasi
            </a>
        </div>
    </header>

    <!-- Main Workspace Container -->
    <div class="flex-1 flex overflow-hidden">
        
        <!-- Sidebar controls & source panel (Left) -->
        <aside class="w-80 bg-white border-r border-gray-200 flex flex-col justify-between shadow-sm z-5">
            <div class="p-5 flex-1 flex flex-col overflow-y-auto space-y-6">
                
                <!-- Menu / Tab Selection -->
                <div>
                    <h2 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Pilih Diagram</h2>
                    <div class="space-y-1">
                        <button id="btn-usecase" onclick="switchDiagram('usecase')" class="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition text-white bg-accent">
                            <span class="flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                </svg>
                                Use Case Diagram
                            </span>
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
                        </button>
                        <button id="btn-class" onclick="switchDiagram('class')" class="w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition text-gray-700 hover:bg-gray-100 hover:text-gray-900">
                            <span class="flex items-center">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                                </svg>
                                Class Diagram
                            </span>
                            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"></path></svg>
                        </button>
                    </div>
                </div>

                <!-- Export & Actions -->
                <div>
                    <h2 class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Ekspor & Berbagi</h2>
                    <div class="space-y-2">
                        <button onclick="exportSVG()" class="w-full flex items-center justify-center px-4 py-2.5 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-green-950 transition">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                            </svg>
                            Unduh Gambar Vector (SVG)
                        </button>
                        <button onclick="copyCode()" class="w-full flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition">
                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path>
                            </svg>
                            Salin Kode Mermaid.js
                        </button>
                    </div>
                </div>

                <!-- Live editor panel (Bonus Premium Feature) -->
                <div class="flex-1 flex flex-col min-h-[180px]">
                    <div class="flex justify-between items-center mb-1">
                        <h2 class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Sumber Kode (Live Edit)</h2>
                        <button onclick="applyEdits()" class="text-xs text-accent hover:underline font-semibold flex items-center">
                            Perbarui Diagram
                        </button>
                    </div>
                    <textarea id="mermaid-src" class="flex-1 w-full p-2.5 font-mono text-xs border border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-accent resize-none bg-gray-50 text-gray-700" spellcheck="false"></textarea>
                </div>

            </div>
            
            <!-- Metadata info footer -->
            <div class="p-4 border-t border-gray-200 bg-gray-50 text-xs text-gray-500">
                <div><strong>Skema Terverifikasi:</strong></div>
                <div class="flex items-center space-x-1 mt-1 text-green-700">
                    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                    <span>schema.sql (10 Tabel Utama)</span>
                </div>
            </div>
        </aside>

        <!-- Canvas rendering area (Right) -->
        <main class="flex-1 flex flex-col min-w-0 bg-gray-100 overflow-hidden relative">
            
            <!-- Zoom controls and status bar -->
            <div class="absolute top-4 left-4 bg-white/90 backdrop-blur border border-gray-200 rounded-lg shadow-sm px-4 py-2 flex items-center space-x-4 z-10">
                <span class="text-xs font-semibold text-gray-600">Skala Diagram:</span>
                <div class="flex items-center space-x-2">
                    <button onclick="zoomOut()" class="p-1 rounded hover:bg-gray-100 text-gray-600">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path></svg>
                    </button>
                    <span id="zoom-val" class="text-xs font-bold text-gray-700 w-10 text-center">100%</span>
                    <button onclick="zoomIn()" class="p-1 rounded hover:bg-gray-100 text-gray-600">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    </button>
                    <button onclick="resetZoom()" class="text-xs text-accent hover:underline font-semibold ml-2">Reset</button>
                </div>
            </div>

            <!-- Canvas Viewport -->
            <div class="flex-1 overflow-auto p-8 flex items-center justify-center canvas-bg" id="diagram-viewport">
                <div id="diagram-container" class="transform origin-center transition-transform duration-200 p-8 shadow-sm rounded-xl border border-gray-100 bg-white">
                    <!-- Mermaid output will go here -->
                    <div id="mermaid-target" class="mermaid"></div>
                </div>
            </div>

            <!-- Bottom status bar -->
            <footer class="bg-white border-t border-gray-200 py-2.5 px-6 flex justify-between text-xs text-gray-500">
                <div>Mermaid JS v10 Renderer &bull; Browser Render Mode</div>
                <div id="status-render" class="text-accent font-semibold flex items-center">
                    <span class="w-2 h-2 rounded-full bg-accent mr-1.5 animate-pulse"></span>
                    Diagram Termuat
                </div>
            </footer>
        </main>

    </div>

    <!-- Script imports -->
    <script src="diagram_definitions.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
    
    <script>
        // Global State variables
        let currentMode = 'usecase';
        let zoomScale = 1;

        // Initialize Mermaid
        mermaid.initialize({
            startOnLoad: false,
            theme: 'neutral',
            securityLevel: 'loose',
            flowchart: {
                useMaxWidth: false,
                htmlLabels: true
            },
            class: {
                useMaxWidth: false
            }
        });

        // Switch active tab and render
        function switchDiagram(mode) {
            currentMode = mode;
            
            // UI tabs styling toggling
            const btnUsecase = document.getElementById('btn-usecase');
            const btnClass = document.getElementById('btn-class');
            
            if (mode === 'usecase') {
                btnUsecase.className = "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition text-white bg-accent shadow-sm";
                btnClass.className = "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition text-gray-700 hover:bg-gray-100 hover:text-gray-900";
                
                document.getElementById('mermaid-src').value = useCaseDiagramDefinition.trim();
            } else {
                btnClass.className = "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition text-white bg-accent shadow-sm";
                btnUsecase.className = "w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-sm font-medium transition text-gray-700 hover:bg-gray-100 hover:text-gray-900";
                
                document.getElementById('mermaid-src').value = classDiagramDefinition.trim();
            }
            
            renderDiagram();
        }

        // Render diagram using Mermaid API
        function renderDiagram() {
            const code = document.getElementById('mermaid-src').value;
            const target = document.getElementById('mermaid-target');
            const statusLabel = document.getElementById('status-render');
            
            statusLabel.innerHTML = `<span class="w-2 h-2 rounded-full bg-yellow-500 mr-1.5 animate-pulse"></span> Rendering...`;
            
            // Clean container
            target.innerHTML = '';
            target.removeAttribute('data-processed');
            
            try {
                // Render diagram
                mermaid.render('diagram-svg', code).then(({ svg }) => {
                    target.innerHTML = svg;
                    statusLabel.innerHTML = `<span class="w-2 h-2 rounded-full bg-accent mr-1.5"></span> Diagram Termuat`;
                }).catch(err => {
                    console.error("Rendering error: ", err);
                    target.innerHTML = `<div class="p-6 text-red-600 bg-red-50 border border-red-200 rounded-lg font-mono text-xs">
                        <strong>Mermaid Render Error:</strong><br>${err.message || err.str || err}
                    </div>`;
                    statusLabel.innerHTML = `<span class="w-2 h-2 rounded-full bg-red-600 mr-1.5"></span> Syntax Error`;
                });
            } catch (e) {
                target.innerHTML = `<div class="p-6 text-red-600 bg-red-50 border border-red-200 rounded-lg font-mono text-xs">
                    <strong>Unexpected Error:</strong><br>${e.message}
                </div>`;
                statusLabel.innerHTML = `<span class="w-2 h-2 rounded-full bg-red-600 mr-1.5"></span> Render Gagal`;
            }
        }

        // Apply edits manually from Textarea
        function applyEdits() {
            renderDiagram();
        }

        // Zoom actions
        function zoomIn() {
            if (zoomScale < 2) {
                zoomScale += 0.1;
                updateZoom();
            }
        }

        function zoomOut() {
            if (zoomScale > 0.4) {
                zoomScale -= 0.1;
                updateZoom();
            }
        }

        function resetZoom() {
            zoomScale = 1;
            updateZoom();
        }

        function updateZoom() {
            const container = document.getElementById('diagram-container');
            container.style.transform = `scale(${zoomScale})`;
            document.getElementById('zoom-val').innerText = `${Math.round(zoomScale * 100)}%`;
        }

        // Export SVG
        function exportSVG() {
            const svgEl = document.querySelector('#mermaid-target svg');
            if (!svgEl) {
                alert("Diagram belum siap diekspor.");
                return;
            }
            
            try {
                const svgData = new XMLSerializer().serializeToString(svgEl);
                const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                
                const link = document.createElement('a');
                link.href = url;
                link.download = `tahfidz_portal_${currentMode}_diagram.svg`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);
            } catch (e) {
                alert("Gagal mengunduh SVG: " + e.message);
            }
        }

        // Copy Mermaid code
        function copyCode() {
            const code = document.getElementById('mermaid-src').value;
            navigator.clipboard.writeText(code).then(() => {
                alert("Kode diagram berhasil disalin ke clipboard!");
            }).catch(err => {
                alert("Gagal menyalin kode: " + err);
            });
        }

        // Initial setup on load
        window.addEventListener('load', () => {
            switchDiagram('usecase');
        });
    </script>
</body>
</html>
